# CampusConnect AI

> **An Intelligent Campus Lost-and-Found System Using Computer Vision and Natural Language Processing**  
> *Subject:* **CAB213: Applied AI – Computer Vision and Natural Language Processing**

---

## 1. Project Overview

Students frequently misplace high-value belongings on university grounds (calculators, water bottles, earbuds, smartphones, student IDs, and notebooks). Finding them traditionally relies on disorganized WhatsApp groups or physical notices.

**CampusConnect AI** automates this by fusing **Deep Transfer Learning for Computer Vision (ResNet-50)** with **Dense Semantic Embeddings for Natural Language Processing (Sentence Transformers)** into a unified multimodal matching engine.

---

## 2. Multimodal AI Architecture

```mermaid
flowchart TD
    subgraph Input["Multimodal Report Ingestion"]
        A1["Lost / Found Item Photo"]
        A2["Item Name & Description"]
        A3["Campus Location & Date"]
    end

    subgraph CV["Computer Vision Pipeline (Unit II & III)"]
        B1["OpenCV Preprocessing<br/>BGR→RGB, Resize 256, CenterCrop 224"]
        B2["ResNet-50 Backbone<br/>(Penultimate GAP Layer)"]
        B3["v ∈ ℝ²⁰⁴⁸ (Normalized Feature Vector)"]
        B1 --> B2 --> B3
    end

    subgraph NLP["NLP Pipeline (Unit IV & V)"]
        C1["Lexical Cleaning & Standardization"]
        C2["Sentence-Transformers<br/>(all-MiniLM-L6-v2)"]
        C3["t ∈ ℝ³⁸⁴ (Dense Semantic Embedding)"]
        C1 --> C2 --> C3
    end

    subgraph Fusion["Multimodal Fusion & Ranking (Unit VI)"]
        D1["Cosine Similarity S_img = (v₁ · v₂) / (||v₁|| ||v₂||)"]
        D2["Cosine Similarity S_text = (t₁ · t₂) / (||t₁|| ||t₂||)"]
        D3["Spatio-Temporal Proximity S_loc"]
        E1["Ensemble Score:<br/>S_total = 0.50·S_img + 0.35·S_text + 0.15·S_loc"]
    end

    A1 --> B1
    A2 --> C1
    A3 --> D3
    B3 --> D1
    C3 --> D2
    D1 --> E1
    D2 --> E1
    D3 --> E1
    E1 --> Output["Ranked Match Results & Confidence Cards"]
```

---

## 3. Mathematical Formulation

### A. Computer Vision (ResNet-50)
Images are standardized via ImageNet channel normalization ($\mu = [0.485, 0.456, 0.406]$, $\sigma = [0.229, 0.224, 0.225]$). By replacing the final fully connected classification layer ($fc$) with an Identity mapping, we tap the 2048-dimensional Global Average Pooling (GAP) tensor:
$$\mathbf{v} = \frac{\mathbf{f}_{\text{ResNet50}}(\mathbf{x})}{\|\mathbf{f}_{\text{ResNet50}}(\mathbf{x})\|_2} \in \mathbb{R}^{2048}$$
Pairwise visual similarity is evaluated using cosine distance:
$$S_{\text{img}}(\mathbf{v}_1, \mathbf{v}_2) = \frac{\mathbf{v}_1 \cdot \mathbf{v}_2}{\|\mathbf{v}_1\|_2 \|\mathbf{v}_2\|_2}$$

### B. Natural Language Processing (Sentence-Transformers)
Descriptions are encoded into dense 384-dimensional contextual vectors using `all-MiniLM-L6-v2`:
$$\mathbf{t} = \frac{\mathbf{f}_{\text{Transformer}}(\text{text})}{\|\mathbf{f}_{\text{Transformer}}(\text{text})\|_2} \in \mathbb{R}^{384}$$
Pairwise semantic similarity:
$$S_{\text{text}}(\mathbf{t}_1, \mathbf{t}_2) = \frac{\mathbf{t}_1 \cdot \mathbf{t}_2}{\|\mathbf{t}_1\|_2 \|\mathbf{t}_2\|_2}$$

### C. Multimodal Fusion Formulation
$$S_{\text{total}} = 
\begin{cases} 
0.50 \cdot S_{\text{img}} + 0.35 \cdot S_{\text{text}} + 0.15 \cdot S_{\text{loc}} & \text{if both images present} \\
0.70 \cdot S_{\text{text}} + 0.30 \cdot S_{\text{loc}} & \text{if image absent} 
\end{cases}$$

---

## 4. CAB213 Syllabus Mapping

| Syllabus Unit | Course Topic | Project Implementation in Code |
| :--- | :--- | :--- |
| **Unit I** | Applied AI Concepts | Practical problem formulation, multimodal agent matching, end-to-end inference pipeline |
| **Unit II** | Computer Vision Fundamentals | OpenCV image reading, BGR-to-RGB color transformation, aspect-ratio letterboxing, normalization (`engine/vision_matcher.py`) |
| **Unit III** | Deep Learning for Vision | ResNet-50 transfer learning, feature extraction via 2048-dim GAP layer (`engine/vision_matcher.py`) |
| **Unit IV** | NLP Fundamentals | Tokenization, regex cleaning, lexical normalization, Jaccard token overlap metrics (`engine/nlp_matcher.py`) |
| **Unit V** | NLP Using Deep Learning | Transformer architecture, attention-based dense sentence embeddings with `all-MiniLM-L6-v2` (`engine/nlp_matcher.py`) |
| **Unit VI** | Integrated Applications | Multimodal score fusion, vector caching in SQLite, real-time thresholding & web interface (`app.py`, `engine/multimodal_matcher.py`) |

---

## 5. Quickstart & How to Run

### Prerequisites
Make sure dependencies are installed:
```bash
pip install -r requirements.txt
```

### 1. Seed Realistic Campus Demo Data
Populates the database with realistic sample items, synthetic item photographs, and cached vector embeddings:
```bash
python3 sample_data/seed_data.py
```

### 2. Run the AI Benchmark Suite (Terminal Viva Demo)
Demonstrates ResNet-50 feature extraction latency, Sentence-Transformer encoding, and multimodal ranking:
```bash
python3 engine/benchmark.py
```

### 3. Launch the Web Application
```bash
python3 app.py
```
Open **[http://127.0.0.1:5001](http://127.0.0.1:5001)** in your browser.

---

## 6. Features & Highlights

1. **Real-Time Object Detection (YOLOv8 & YOLO11)**:
   * Real-time edge detection and auto-categorization of campus items using single-shot neural networks.
   * Visual bounding box rendering and confidence overlays via OpenCV.
2. **Instant Match Recommendations**:
   * Automatically cross-references newly reported items with the complementary database pool (Lost vs Found).
3. **Side-by-Side Confidence Cards**:
   * Displays visual comparison, match percentage dials, progress breakdown bars, and automated natural language explanations.
4. **Admin Management Panel (`/admin`)**:
   * View all active reports across campus, filter statuses, and mark recovered items as reunited.
