import os
import sys
import json
import csv
import time
import urllib.request
import urllib.parse
from PIL import Image
import io

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
DATASET_DIR = os.path.join(BASE_DIR, 'dataset')
IMAGES_DIR = os.path.join(DATASET_DIR, 'images')
STATIC_SEED_DIR = os.path.join(BASE_DIR, 'static', 'uploads', 'seed')

os.makedirs(IMAGES_DIR, exist_ok=True)
os.makedirs(STATIC_SEED_DIR, exist_ok=True)

USER_AGENT = 'CampusConnectDatasetBot/1.0 (academic.project.cab213@university.edu)'

def search_wiki_image(query):
    """
    Finds direct thumb URL from Wikimedia Commons for a query.
    """
    url = f'https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch={urllib.parse.quote(query)}&gsrnamespace=6&gsrlimit=3&prop=imageinfo&iiprop=url&iiurlwidth=800&format=json'
    headers = {'User-Agent': USER_AGENT}
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            pages = data.get('query', {}).get('pages', {})
            for p in pages.values():
                info = p.get('imageinfo', [{}])[0]
                u = info.get('thumburl') or info.get('url')
                if u and not u.endswith('.svg.png') and not u.endswith('.tif'):
                    return u
    except Exception as e:
        print(f"Error querying Wikimedia for '{query}': {e}")
    return None

def download_and_process_image(url, target_path):
    """
    Downloads image from URL, converts to RGB JPEG, resizes reasonably, and saves.
    """
    headers = {'User-Agent': USER_AGENT}
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=12) as resp:
            content = resp.read()
        
        img = Image.open(io.BytesIO(content))
        img = img.convert('RGB')
        
        # Resize if overly large
        max_dim = 900
        if max(img.size) > max_dim:
            img.thumbnail((max_dim, max_dim), Image.Resampling.LANCZOS)
            
        img.save(target_path, 'JPEG', quality=90)
        return True
    except Exception as e:
        print(f"Failed to download/process {url}: {e}")
        return False

# Dataset Item Definitions
DATASET_ITEMS = [
    # ------------------ PAIR 1: CASIO fx-991EX CALCULATOR ------------------
    {
        'id': 'L01',
        'pair_id': 'PAIR_01',
        'type': 'lost',
        'title': 'Casio fx-991EX ClassWiz Scientific Calculator',
        'category': 'Stationery & Calculators',
        'location': 'Central Library - Reading Hall',
        'date_event': '2026-11-18',
        'description': 'Black matte casing scientific calculator with high-resolution LCD and dual solar power strip. Left on desk near window.',
        'image_filename': 'casio_991ex_lost.jpg',
        'wiki_query': 'Casio fx-991EX',
        'reporter': 'Aarav Sharma'
    },
    {
        'id': 'F01',
        'pair_id': 'PAIR_01',
        'type': 'found',
        'title': 'Black Scientific Calculator',
        'category': 'Stationery & Calculators',
        'location': 'Central Library - 1st Floor',
        'date_event': '2026-11-18',
        'description': 'Found black Casio engineering calculator with dual power solar cell on library study table.',
        'image_filename': 'casio_991ex_found.jpg',
        'wiki_query': 'Casio fx-991EX scientific calculator',
        'reporter': 'Priya Patel'
    },

    # ------------------ PAIR 2: TI-84 GRAPHING CALCULATOR ------------------
    {
        'id': 'L02',
        'pair_id': 'PAIR_02',
        'type': 'lost',
        'title': 'Texas Instruments TI-84 Plus Graphing Calculator',
        'category': 'Stationery & Calculators',
        'location': 'Engineering Block A - Ground Floor',
        'date_event': '2026-11-19',
        'description': 'Black TI-84 Plus graphing calculator with color backlit display. Lost after Calculus lecture in room 102.',
        'image_filename': 'ti84_lost.jpg',
        'wiki_query': 'TI-84 Plus CE calculator',
        'reporter': 'Devanshi Gupta'
    },
    {
        'id': 'F02',
        'pair_id': 'PAIR_02',
        'type': 'found',
        'title': 'TI Graphing Calculator',
        'category': 'Stationery & Calculators',
        'location': 'Engineering Block A - Ground Floor',
        'date_event': '2026-11-19',
        'description': 'Found Texas Instruments color screen graphing calculator in Block A corridor.',
        'image_filename': 'ti84_found.jpg',
        'wiki_query': 'TI-84 Plus graphing calculator',
        'reporter': 'Rohan Das'
    },

    # ------------------ PAIR 3: BLUE MILTON WATER BOTTLE ------------------
    {
        'id': 'L03',
        'pair_id': 'PAIR_03',
        'type': 'lost',
        'title': 'Milton Thermosteel Blue Insulated Water Bottle',
        'category': 'Bottles & Containers',
        'location': 'Indoor Sports Arena & Gymnasium',
        'date_event': '2026-11-19',
        'description': 'Stainless steel matte navy blue thermal flask 750ml with silver screw ring and carrying loop.',
        'image_filename': 'milton_bottle_lost.jpg',
        'wiki_query': 'blue vacuum flask thermos bottle',
        'reporter': 'Siddharth Verma'
    },
    {
        'id': 'F03',
        'pair_id': 'PAIR_03',
        'type': 'found',
        'title': 'Blue Stainless Steel Water Bottle',
        'category': 'Bottles & Containers',
        'location': 'Student Cafeteria & Food Court',
        'date_event': '2026-11-19',
        'description': 'Navy blue metallic vacuum water bottle found left on the cafeteria bench table.',
        'image_filename': 'milton_bottle_found.jpg',
        'wiki_query': 'blue stainless steel thermos',
        'reporter': 'Ananya Singh'
    },

    # ------------------ PAIR 4: HYDRO FLASK BLACK BOTTLE ------------------
    {
        'id': 'L04',
        'pair_id': 'PAIR_04',
        'type': 'lost',
        'title': 'Hydro Flask 32oz Wide Mouth Black Water Bottle',
        'category': 'Bottles & Containers',
        'location': 'Campus Grounds & Athletic Track',
        'date_event': '2026-11-20',
        'description': 'All-black matte insulated metal water flask with wide mouth and flexible handle cap.',
        'image_filename': 'hydroflask_lost.jpg',
        'wiki_query': 'black metal water bottle flask',
        'reporter': 'Karan Malhotra'
    },
    {
        'id': 'F04',
        'pair_id': 'PAIR_04',
        'type': 'found',
        'title': 'Black Metal Sports Flask',
        'category': 'Bottles & Containers',
        'location': 'Campus Grounds & Athletic Track',
        'date_event': '2026-11-20',
        'description': 'Found black powder-coated thermal water bottle with carry strap on athletic bleachers.',
        'image_filename': 'hydroflask_found.jpg',
        'wiki_query': 'black vacuum bottle insulated',
        'reporter': 'Harsh Vardhan'
    },

    # ------------------ PAIR 5: APPLE AIRPODS PRO ------------------
    {
        'id': 'L05',
        'pair_id': 'PAIR_05',
        'type': 'lost',
        'title': 'Apple AirPods Pro in White Wireless Case',
        'category': 'Electronics & Gadgets',
        'location': 'Student Cafeteria & Food Court',
        'date_event': '2026-11-19',
        'description': 'Glossy white AirPods Pro wireless charging case with green status LED and silicon ear tips.',
        'image_filename': 'airpods_lost.jpg',
        'wiki_query': 'AirPods Pro white charging case',
        'reporter': 'Rhea Kapoor'
    },
    {
        'id': 'F05',
        'pair_id': 'PAIR_05',
        'type': 'found',
        'title': 'White Wireless Earbuds Charging Box',
        'category': 'Electronics & Gadgets',
        'location': 'Student Cafeteria & Food Court',
        'date_event': '2026-11-19',
        'description': 'Found white wireless Bluetooth earbuds case with lightning port on corner table.',
        'image_filename': 'airpods_found.jpg',
        'wiki_query': 'Apple AirPods Pro wireless earbuds',
        'reporter': 'Aditya Roy'
    },

    # ------------------ PAIR 6: BOAT AIRDOPES BLACK ------------------
    {
        'id': 'L06',
        'pair_id': 'PAIR_06',
        'type': 'lost',
        'title': 'boAt Airdopes True Wireless Earbuds Black',
        'category': 'Electronics & Gadgets',
        'location': 'Hostel Mess & Common Room',
        'date_event': '2026-11-20',
        'description': 'Matte black pebble-shaped wireless earbud case with boAt logo and Type-C charging slot.',
        'image_filename': 'boat_earbuds_lost.jpg',
        'wiki_query': 'black wireless earbuds charging case',
        'reporter': 'Nikhil Jain'
    },
    {
        'id': 'F06',
        'pair_id': 'PAIR_06',
        'type': 'found',
        'title': 'Black Bluetooth Earbuds in Case',
        'category': 'Electronics & Gadgets',
        'location': 'Hostel Mess & Common Room',
        'date_event': '2026-11-20',
        'description': 'Found black wireless earphone case with charging LED indicators on dining hall table.',
        'image_filename': 'boat_earbuds_found.jpg',
        'wiki_query': 'black true wireless earbuds',
        'reporter': 'Vikram Mehra'
    },

    # ------------------ PAIR 7: MACBOOK POWER ADAPTER ------------------
    {
        'id': 'L07',
        'pair_id': 'PAIR_07',
        'type': 'lost',
        'title': 'Apple 67W USB-C Power Adapter & MagSafe Cable',
        'category': 'Electronics & Gadgets',
        'location': 'Engineering Block B - Computer Labs',
        'date_event': '2026-11-18',
        'description': 'White square Apple laptop charging adapter block with white braided USB-C power cord.',
        'image_filename': 'macbook_charger_lost.jpg',
        'wiki_query': 'Apple USB-C power adapter',
        'reporter': 'Tanvi Sethi'
    },
    {
        'id': 'F07',
        'pair_id': 'PAIR_07',
        'type': 'found',
        'title': 'White MacBook Laptop Charger',
        'category': 'Electronics & Gadgets',
        'location': 'Engineering Block B - Computer Labs',
        'date_event': '2026-11-18',
        'description': 'Found white Apple USB-C laptop charger left plugged into socket in computer lab 204.',
        'image_filename': 'macbook_charger_found.jpg',
        'wiki_query': 'Apple power adapter charger',
        'reporter': 'Mohit Agarwal'
    },

    # ------------------ PAIR 8: LENOVO THINKPAD CHARGER ------------------
    {
        'id': 'L08',
        'pair_id': 'PAIR_08',
        'type': 'lost',
        'title': 'Lenovo 65W AC Adapter Charger for ThinkPad',
        'category': 'Electronics & Gadgets',
        'location': 'Central Library - Digital Section',
        'date_event': '2026-11-17',
        'description': 'Black rectangular laptop power brick with yellow rectangular slim-tip connector and cable.',
        'image_filename': 'lenovo_charger_lost.jpg',
        'wiki_query': 'Lenovo 65W AC adapter ThinkPad',
        'reporter': 'Kunal Joshi'
    },
    {
        'id': 'F08',
        'pair_id': 'PAIR_08',
        'type': 'found',
        'title': 'Black Lenovo Laptop Power Cord',
        'category': 'Electronics & Gadgets',
        'location': 'Central Library - 1st Floor',
        'date_event': '2026-11-17',
        'description': 'Found black Lenovo branded laptop power brick near digital catalog terminal.',
        'image_filename': 'lenovo_charger_found.jpg',
        'wiki_query': 'ThinkPad power adapter laptop',
        'reporter': 'Shweta Nair'
    },

    # ------------------ PAIR 9: BROWN LEATHER WALLET ------------------
    {
        'id': 'L09',
        'pair_id': 'PAIR_09',
        'type': 'lost',
        'title': 'Brown Genuine Leather Bifold Wallet',
        'category': 'Wallets & Cards',
        'location': 'Student Cafeteria & Food Court',
        'date_event': '2026-11-19',
        'description': 'Distressed dark brown leather wallet containing driving license, student metro card, and cash.',
        'image_filename': 'leather_wallet_lost.jpg',
        'wiki_query': 'Brown leather wallet bifold',
        'reporter': 'Manish Tiwari'
    },
    {
        'id': 'F09',
        'pair_id': 'PAIR_09',
        'type': 'found',
        'title': 'Brown Leather Men\'s Wallet',
        'category': 'Wallets & Cards',
        'location': 'Student Cafeteria & Food Court',
        'date_event': '2026-11-19',
        'description': 'Found brown leather wallet near food court payment cash counter.',
        'image_filename': 'leather_wallet_found.jpg',
        'wiki_query': 'leather wallet cash',
        'reporter': 'Deepak Rao'
    },

    # ------------------ PAIR 10: STUDENT ID ON BLUE LANYARD ------------------
    {
        'id': 'L10',
        'pair_id': 'PAIR_10',
        'type': 'lost',
        'title': 'University Student ID Card on Blue Lanyard',
        'category': 'Wallets & Cards',
        'location': 'Engineering Block C - Seminar Hall',
        'date_event': '2026-11-20',
        'description': 'Student RFID identity card in clear protective badge sleeve attached to royal blue lanyard.',
        'image_filename': 'id_lanyard_lost.jpg',
        'wiki_query': 'identity card badge lanyard',
        'reporter': 'Sanya Mirza'
    },
    {
        'id': 'F10',
        'pair_id': 'PAIR_10',
        'type': 'found',
        'title': 'Campus Identity Badge with Blue Ribbon',
        'category': 'Wallets & Cards',
        'location': 'Engineering Block C - Seminar Hall',
        'date_event': '2026-11-20',
        'description': 'Found university student pass card with blue ribbon strap in auditorium seat row F.',
        'image_filename': 'id_lanyard_found.jpg',
        'wiki_query': 'id card badge holder lanyard',
        'reporter': 'Sameer Khan'
    },

    # ------------------ PAIR 11: WILDCRAFT BLACK BACKPACK ------------------
    {
        'id': 'L11',
        'pair_id': 'PAIR_11',
        'type': 'lost',
        'title': 'Wildcraft Black College Backpack with Orange Accents',
        'category': 'Bags & Backpacks',
        'location': 'Indoor Sports Arena & Gymnasium',
        'date_event': '2026-11-18',
        'description': 'Black nylon multi-pocket backpack with orange pull cords and water bottle mesh side pocket.',
        'image_filename': 'backpack_lost.jpg',
        'wiki_query': 'backpack orange black',
        'reporter': 'Varun Dhawan'
    },
    {
        'id': 'F11',
        'pair_id': 'PAIR_11',
        'type': 'found',
        'title': 'Black School Backpack with Orange Trim',
        'category': 'Bags & Backpacks',
        'location': 'Indoor Sports Arena & Gymnasium',
        'date_event': '2026-11-18',
        'description': 'Found black college bag with orange highlights in basketball court spectator seating.',
        'image_filename': 'backpack_found.jpg',
        'wiki_query': 'black and orange backpack bag',
        'reporter': 'Rahul Dravid'
    },

    # ------------------ PAIR 12: MOTORBIKE KEY WITH KEYCHAIN ------------------
    {
        'id': 'L12',
        'pair_id': 'PAIR_12',
        'type': 'lost',
        'title': 'Yamaha Bike Key with Brown Leather Keychain',
        'category': 'Keys & Chains',
        'location': 'Main Administrative Block',
        'date_event': '2026-11-20',
        'description': 'Silver ignition key with black plastic head attached to a brown leather strap keychain.',
        'image_filename': 'keys_lost.jpg',
        'wiki_query': 'motorcycle ignition key keychain',
        'reporter': 'Gaurav Kulkarni'
    },
    {
        'id': 'F12',
        'pair_id': 'PAIR_12',
        'type': 'found',
        'title': 'Motorcycle Key on Leather Ring',
        'category': 'Keys & Chains',
        'location': 'Main Administrative Block',
        'date_event': '2026-11-20',
        'description': 'Found single bike key with dark leather fob near the admin block bike parking ramp.',
        'image_filename': 'keys_found.jpg',
        'wiki_query': 'car motorcycle key leather ring',
        'reporter': 'Ramesh Powar'
    },

    # ------------------ PAIR 13: RAY-BAN EYEGLASSES IN CASE ------------------
    {
        'id': 'L13',
        'pair_id': 'PAIR_13',
        'type': 'lost',
        'title': 'Ray-Ban Matte Black Eyeglasses in Hard Case',
        'category': 'Eyewear & Accessories',
        'location': 'Central Library - Reading Hall',
        'date_event': '2026-11-19',
        'description': 'Rectangular matte black frame prescription spectacles in protective black clamshell case.',
        'image_filename': 'glasses_lost.jpg',
        'wiki_query': 'eyeglasses black frame case',
        'reporter': 'Sneha Reddy'
    },
    {
        'id': 'F13',
        'pair_id': 'PAIR_13',
        'type': 'found',
        'title': 'Black Reading Glasses in Hard Shell Case',
        'category': 'Eyewear & Accessories',
        'location': 'Central Library - Reading Hall',
        'date_event': '2026-11-19',
        'description': 'Found black spectacles inside black hard case on desk 42 in library reading hall.',
        'image_filename': 'glasses_found.jpg',
        'wiki_query': 'spectacles case eyeglasses',
        'reporter': 'Kavita Krishnan'
    },

    # ------------------ PAIR 14: ENGINEERING MATHEMATICS BOOK ------------------
    {
        'id': 'L14',
        'pair_id': 'PAIR_14',
        'type': 'lost',
        'title': 'Higher Engineering Mathematics Textbook (BS Grewal)',
        'category': 'Books & Notes',
        'location': 'Engineering Block A - Ground Floor',
        'date_event': '2026-11-18',
        'description': 'Thick blue and white paperback engineering textbook with sticky bookmarks on pages.',
        'image_filename': 'textbook_lost.jpg',
        'wiki_query': 'paperback textbook book',
        'reporter': 'Arjun Nambiar'
    },
    {
        'id': 'F14',
        'pair_id': 'PAIR_14',
        'type': 'found',
        'title': 'Engineering Math Paperback Book',
        'category': 'Books & Notes',
        'location': 'Engineering Block A - Ground Floor',
        'date_event': '2026-11-18',
        'description': 'Found thick university mathematics textbook left behind on lecture hall front bench.',
        'image_filename': 'textbook_found.jpg',
        'wiki_query': 'textbook open on desk',
        'reporter': 'Rohit Sharma'
    },

    # ------------------ PAIR 15: BLUE FOLDABLE UMBRELLA ------------------
    {
        'id': 'L15',
        'pair_id': 'PAIR_15',
        'type': 'lost',
        'title': 'Blue Three-Fold Automatic Compact Umbrella',
        'category': 'Personal Accessories',
        'location': 'Student Activity Center (SAC)',
        'date_event': '2026-11-20',
        'description': 'Navy blue 3-fold collapsible umbrella with wrist cord and button release handle.',
        'image_filename': 'umbrella_lost.jpg',
        'wiki_query': 'blue folding umbrella compact',
        'reporter': 'Ishita Roy'
    },
    {
        'id': 'F15',
        'pair_id': 'PAIR_15',
        'type': 'found',
        'title': 'Navy Blue Pocket Umbrella',
        'category': 'Personal Accessories',
        'location': 'Student Activity Center (SAC)',
        'date_event': '2026-11-20',
        'description': 'Found blue compact folding umbrella in the umbrella stand at SAC main reception.',
        'image_filename': 'umbrella_found.jpg',
        'wiki_query': 'blue umbrella compact',
        'reporter': 'Sunil Gavaskar'
    },

    # ------------------ 5 HARD DISTRACTORS / TRUE NEGATIVES ------------------
    {
        'id': 'F16',
        'pair_id': 'DISTRACTOR_01',
        'type': 'found',
        'title': 'Casio fx-82MS Scientific Calculator',
        'category': 'Stationery & Calculators',
        'location': 'Engineering Block B - Computer Labs',
        'date_event': '2026-11-17',
        'description': 'Grey two-line display standard Casio calculator with plastic slide cover found in lab 302.',
        'image_filename': 'casio_82ms_distractor.jpg',
        'wiki_query': 'Casio fx-82MS',
        'reporter': 'Staff Lab Tech'
    },
    {
        'id': 'F17',
        'pair_id': 'DISTRACTOR_02',
        'type': 'found',
        'title': 'Tupperware Lime Green Plastic Sipper Bottle',
        'category': 'Bottles & Containers',
        'location': 'Student Activity Center (SAC)',
        'date_event': '2026-11-20',
        'description': 'Translucent lime green plastic water sipper bottle with flip top spout found in lobby.',
        'image_filename': 'tupperware_green_distractor.jpg',
        'wiki_query': 'green plastic water bottle gym',
        'reporter': 'Gym Attendant'
    },
    {
        'id': 'F18',
        'pair_id': 'DISTRACTOR_03',
        'type': 'found',
        'title': 'Sony WH-1000XM4 Wireless Over-Ear Headphones',
        'category': 'Electronics & Gadgets',
        'location': 'Central Library - Digital Section',
        'date_event': '2026-11-19',
        'description': 'Black over-ear padded noise cancelling headphones in black travel case found at computer desk.',
        'image_filename': 'sony_headphones_distractor.jpg',
        'wiki_query': 'Sony over-ear headphones black',
        'reporter': 'Library Assistant'
    },
    {
        'id': 'F19',
        'pair_id': 'DISTRACTOR_04',
        'type': 'found',
        'title': 'Royal Blue Sports Gym Duffle Bag',
        'category': 'Bags & Backpacks',
        'location': 'Campus Grounds & Athletic Track',
        'date_event': '2026-11-18',
        'description': 'Cylindrical royal blue sports duffle bag with white straps left near football goal post.',
        'image_filename': 'blue_duffle_distractor.jpg',
        'wiki_query': 'blue gym duffel bag',
        'reporter': 'Grounds Keeper'
    },
    {
        'id': 'F20',
        'pair_id': 'DISTRACTOR_05',
        'type': 'found',
        'title': 'Gold Framed Aviator Sunglasses in Leather Pouch',
        'category': 'Eyewear & Accessories',
        'location': 'Campus Grounds & Athletic Track',
        'date_event': '2026-11-20',
        'description': 'Classic gold wire frame teardrop aviator sunglasses with green tinted lenses.',
        'image_filename': 'aviators_distractor.jpg',
        'wiki_query': 'aviator sunglasses gold frame',
        'reporter': 'Student Volunteer'
    }
]

def build_dataset():
    print(f"[Dataset Builder] Starting build of CampusConnect AI Benchmark Dataset...")
    print(f"Target Directory: {DATASET_DIR}")
    
    csv_rows = []
    headers = [
        'item_id', 'pair_id', 'item_type', 'title', 'category', 
        'campus_location', 'date_event', 'description', 
        'reporter_name', 'image_path', 'ground_truth_match_id'
    ]
    
    total = len(DATASET_ITEMS)
    for idx, item in enumerate(DATASET_ITEMS, 1):
        target_img_dataset = os.path.join(IMAGES_DIR, item['image_filename'])
        target_img_static = os.path.join(STATIC_SEED_DIR, item['image_filename'])
        
        # Determine ground truth match ID
        if item['pair_id'].startswith('PAIR_'):
            # Find opposite item with same pair_id
            opp_type = 'found' if item['type'] == 'lost' else 'lost'
            matches = [i['id'] for i in DATASET_ITEMS if i['pair_id'] == item['pair_id'] and i['type'] == opp_type]
            gt_id = matches[0] if matches else 'NONE'
        else:
            gt_id = 'NONE' # Distractor
            
        print(f"[{idx}/{total}] Processing #{item['id']} ({item['title']})...")
        
        # Check if image already exists
        if not os.path.exists(target_img_dataset) or os.path.getsize(target_img_dataset) < 5000:
            thumb_url = search_wiki_image(item['wiki_query'])
            if thumb_url:
                print(f"    Downloading from: {thumb_url[:70]}...")
                success = download_and_process_image(thumb_url, target_img_dataset)
                if not success:
                    print(f"    Fallback: Generating clean photorealistic placeholder for {item['image_filename']}")
                    from PIL import ImageDraw
                    fallback = Image.new('RGB', (600, 600), color=(240, 243, 246))
                    d = ImageDraw.Draw(fallback)
                    d.rectangle([50, 50, 550, 550], fill=(225, 230, 238), outline=(180, 190, 205), width=3)
                    d.text((300, 300), item['title'], fill=(60, 70, 90), anchor="mm")
                    fallback.save(target_img_dataset, 'JPEG', quality=90)
            else:
                print(f"    No wiki image found for '{item['wiki_query']}'. Generating fallback image.")
                from PIL import ImageDraw
                fallback = Image.new('RGB', (600, 600), color=(240, 243, 246))
                d = ImageDraw.Draw(fallback)
                d.rectangle([50, 50, 550, 550], fill=(225, 230, 238), outline=(180, 190, 205), width=3)
                d.text((300, 300), item['title'], fill=(60, 70, 90), anchor="mm")
                fallback.save(target_img_dataset, 'JPEG', quality=90)
                
            time.sleep(0.5) # Gentle rate limiting
        
        # Sync with static seed dir
        if os.path.exists(target_img_dataset):
            import shutil
            shutil.copy2(target_img_dataset, target_img_static)
            
        csv_rows.append({
            'item_id': item['id'],
            'pair_id': item['pair_id'],
            'item_type': item['type'],
            'title': item['title'],
            'category': item['category'],
            'campus_location': item['location'],
            'date_event': item['date_event'],
            'description': item['description'],
            'reporter_name': item['reporter'],
            'image_path': f"images/{item['image_filename']}",
            'ground_truth_match_id': gt_id
        })
        
    csv_file = os.path.join(DATASET_DIR, 'campus_lost_and_found_dataset.csv')
    with open(csv_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        writer.writerows(csv_rows)
        
    print(f"\n[Dataset Builder] SUCCESS!")
    print(f"  ✓ Exported CSV: {csv_file} ({len(csv_rows)} records)")
    print(f"  ✓ Images Saved: {IMAGES_DIR} ({len(os.listdir(IMAGES_DIR))} images)")
    print(f"  ✓ Static Mirror: {STATIC_SEED_DIR}")

if __name__ == '__main__':
    build_dataset()
