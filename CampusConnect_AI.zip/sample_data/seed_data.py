import os
import sys
import csv
import builtins
from PIL import Image

# Protect against Errno 5 when running in detached/daemonized environments
_real_print = builtins.print
def safe_print(*args, **kwargs):
    try:
        _real_print(*args, **kwargs)
    except (OSError, IOError):
        pass
builtins.print = safe_print

# Add project root to sys.path
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, BASE_DIR)

from database.db_manager import (
    init_db, get_or_create_user, add_item, save_embeddings,
    record_match, get_db_connection
)
from engine.vision_matcher import get_vision_matcher
from engine.nlp_matcher import get_nlp_matcher
from engine.multimodal_matcher import get_multimodal_matcher
from config import UPLOAD_FOLDER

def seed_database():
    print("[Seed] Initializing database schema...")
    init_db()

    vision = get_vision_matcher()
    nlp = get_nlp_matcher()
    multimodal = get_multimodal_matcher()

    # Clear existing items and matches for clean state
    conn = get_db_connection()
    conn.execute("DELETE FROM matches")
    conn.execute("DELETE FROM item_embeddings")
    conn.execute("DELETE FROM items")
    conn.commit()
    conn.close()

    csv_path = os.path.join(BASE_DIR, 'dataset', 'campus_lost_and_found_dataset.csv')
    if not os.path.exists(csv_path):
        print(f"[Seed] CSV dataset not found at {csv_path}. Running build_dataset...")
        from sample_data.build_dataset import build_dataset
        build_dataset()

    print(f"[Seed] Reading authentic campus items from {csv_path}...")
    items = []
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append(row)

    print(f"[Seed] Extracting deep multimodal embeddings for {len(items)} items...")
    inserted_items = []
    for item in items:
        # Reporter user
        user_name = item.get('reporter_name', 'Campus Student')
        email_handle = user_name.lower().replace(' ', '.')
        user_id = get_or_create_user(
            name=user_name,
            email=f"{email_handle}@univ.edu",
            student_id=f"22{item['item_id']}99",
            phone="+91 98765 00000"
        )

        # Image path (rel to static)
        # Note: dataset/images/<filename> is mirrored into static/uploads/seed/<filename>
        filename = os.path.basename(item['image_path'])
        image_rel_path = f"uploads/seed/{filename}"
        full_img_path = os.path.join(BASE_DIR, 'static', image_rel_path)

        # Insert item into SQLite
        item_id = add_item(
            user_id=user_id,
            item_type=item['item_type'],
            title=item['title'],
            description=item['description'],
            category=item['category'],
            location=item['campus_location'],
            date_event=item['date_event'],
            image_path=image_rel_path,
            contact_info=f"{email_handle}@univ.edu"
        )

        # Compute embeddings
        img_emb = vision.extract_features(full_img_path)
        text_emb = nlp.extract_features(item['title'], item['description'])

        save_embeddings(item_id, text_emb, img_emb)
        item['db_id'] = item_id
        item['text_emb'] = text_emb
        item['img_emb'] = img_emb
        inserted_items.append(item)
        print(f"  ✓ Added #{item['item_id']} (DB ID {item_id}): {item['title']} ({item['item_type']})")

    # Compute pairwise cross-matches (Lost vs Found)
    print("\n[Seed] Computing Multimodal Cross-Matches (Lost vs Found)...")
    lost_items = [i for i in inserted_items if i['item_type'] == 'lost']
    found_items = [i for i in inserted_items if i['item_type'] == 'found']

    for l in lost_items:
        for f in found_items:
            metrics = multimodal.match_pair(
                item1={
                    'title': l['title'],
                    'description': l['description'],
                    'location': l['campus_location']
                },
                item2={
                    'title': f['title'],
                    'description': f['description'],
                    'location': f['campus_location']
                },
                emb1=(l['text_emb'], l['img_emb']),
                emb2=(f['text_emb'], f['img_emb'])
            )
            # Record match if score meets threshold
            if metrics['total_score'] >= 0.25:
                record_match(
                    lost_item_id=l['db_id'],
                    found_item_id=f['db_id'],
                    total_score=metrics['total_score'],
                    vision_score=metrics['vision_score'],
                    text_score=metrics['text_score'],
                    location_score=metrics['location_score']
                )

    print("\n[Seed] Complete! Database seeded successfully with 35 multimodal campus items.")

if __name__ == '__main__':
    seed_database()
