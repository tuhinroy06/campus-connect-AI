import os
import sys
import urllib.request
from PIL import Image
import io

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
DATASET_IMG_DIR = os.path.join(BASE_DIR, 'dataset', 'images')
STATIC_SEED_DIR = os.path.join(BASE_DIR, 'static', 'uploads', 'seed')

os.makedirs(DATASET_IMG_DIR, exist_ok=True)
os.makedirs(STATIC_SEED_DIR, exist_ok=True)

CURATED_PHOTOS = {
    # 1. Calculators
    'casio_991ex_lost.jpg': 'https://images.unsplash.com/photo-1594980596870-8aa52a78d8cd?w=600&q=80',
    'casio_991ex_found.jpg': 'https://images.unsplash.com/photo-1587145820266-a5951ee6f620?w=600&q=80',
    'ti84_lost.jpg': 'https://images.unsplash.com/photo-1594980596870-8aa52a78d8cd?w=600&q=80',
    'ti84_found.jpg': 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=600&q=80',
    'casio_82ms_distractor.jpg': 'https://images.unsplash.com/photo-1587145820266-a5951ee6f620?w=600&q=80',

    # 2. Water Bottles
    'milton_bottle_lost.jpg': 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=600&q=80',
    'milton_bottle_found.jpg': 'https://images.unsplash.com/photo-1544816155-12df9643f363?w=600&q=80',
    'hydroflask_lost.jpg': 'https://images.unsplash.com/photo-1523362628745-0c100150b504?w=600&q=80',
    'hydroflask_found.jpg': 'https://images.unsplash.com/photo-1589365278144-c9e705f843ba?w=600&q=80',
    'tupperware_green_distractor.jpg': 'https://images.unsplash.com/photo-1544003484-3cd181d17917?w=600&q=80',

    # 3. Audio & Earbuds
    'airpods_lost.jpg': 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=600&q=80',
    'airpods_found.jpg': 'https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb?w=600&q=80',
    'boat_earbuds_lost.jpg': 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=600&q=80',
    'boat_earbuds_found.jpg': 'https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=600&q=80',
    'sony_headphones_distractor.jpg': 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&q=80',

    # 4. Chargers & Adapters
    'macbook_charger_lost.jpg': 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=600&q=80',
    'macbook_charger_found.jpg': 'https://images.unsplash.com/photo-1583863788434-e58a36330cf0?w=600&q=80',
    'lenovo_charger_lost.jpg': 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=600&q=80',
    'lenovo_charger_found.jpg': 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=600&q=80',

    # 5. Wallets & IDs
    'leather_wallet_lost.jpg': 'https://images.unsplash.com/photo-1627123424574-724758594e93?w=600&q=80',
    'leather_wallet_found.jpg': 'https://images.unsplash.com/photo-1627123424574-724758594e93?w=600&q=80',
    'id_lanyard_lost.jpg': 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&q=80',
    'id_lanyard_found.jpg': 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&q=80',

    # 6. Bags & Backpacks
    'backpack_lost.jpg': 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&q=80',
    'backpack_found.jpg': 'https://images.unsplash.com/photo-1581605405669-fcdf81165afa?w=600&q=80',
    'blue_duffle_distractor.jpg': 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&q=80',

    # 7. Keys
    'keys_lost.jpg': 'https://images.unsplash.com/photo-1582139329536-e7284fece509?w=600&q=80',
    'keys_found.jpg': 'https://images.unsplash.com/photo-1582139329536-e7284fece509?w=600&q=80',

    # 8. Eyewear
    'glasses_lost.jpg': 'https://images.unsplash.com/photo-1574258495973-f010dfbb5371?w=600&q=80',
    'glasses_found.jpg': 'https://images.unsplash.com/photo-1591076482161-42ce6da69f67?w=600&q=80',
    'aviators_distractor.jpg': 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=600&q=80',

    # 9. Books
    'textbook_lost.jpg': 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=600&q=80',
    'textbook_found.jpg': 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=600&q=80',

    # 10. Umbrellas
    'umbrella_lost.jpg': 'https://images.unsplash.com/photo-1534353436294-0dbd4bdac845?w=600&q=80',
    'umbrella_found.jpg': 'https://images.unsplash.com/photo-1517411032315-54ef2cb783bb?w=600&q=80'
}

def refresh_images():
    print(f"[Refresh] Downloading and standardizing 35 authentic photographs...")
    headers = {'User-Agent': 'Mozilla/5.0'}

    for idx, (filename, url) in enumerate(CURATED_PHOTOS.items(), 1):
        target_dataset = os.path.join(DATASET_IMG_DIR, filename)
        target_static = os.path.join(STATIC_SEED_DIR, filename)

        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=8) as resp:
                data = resp.read()

            img = Image.open(io.BytesIO(data)).convert('RGB')
            # Normalize size
            if max(img.size) > 800:
                img.thumbnail((800, 800), Image.Resampling.LANCZOS)

            img.save(target_dataset, 'JPEG', quality=92)
            img.save(target_static, 'JPEG', quality=92)
            print(f"  [{idx:02d}/35] ✓ {filename:<32} ({img.size[0]}x{img.size[1]}px, {os.path.getsize(target_static)//1024} KB)")
        except Exception as e:
            print(f"  [{idx:02d}/35] ✗ {filename}: {e}")

    print("\n[Refresh] All photographs successfully updated on disk.")
    
    # Re-seed database
    print("[Refresh] Re-seeding database and recomputing visual + semantic embeddings...")
    sys.path.insert(0, BASE_DIR)
    from sample_data.seed_data import seed_database
    seed_database()

    # Rebuild vector index
    from engine.vector_index import get_vector_index
    get_vector_index().rebuild_index()
    print("[Refresh] Vector index rebuilt successfully.")

if __name__ == '__main__':
    refresh_images()
