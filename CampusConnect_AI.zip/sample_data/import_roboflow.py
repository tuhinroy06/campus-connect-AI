import os
import sys
import glob
import shutil
import zipfile
import csv
import argparse

# Add parent directory to path
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, BASE_DIR)

from database.db_manager import (
    init_db, get_or_create_user, add_item, save_embeddings,
    record_match, get_db_connection
)
from engine.vision_matcher import get_vision_matcher
from engine.nlp_matcher import get_nlp_matcher
from engine.multimodal_matcher import get_multimodal_matcher

# Roboflow class to CampusConnect category mapping
ROBOFLOW_CATEGORY_MAP = {
    'calculator': {
        'category': 'Stationery & Calculators',
        'default_title': 'Engineering Scientific Calculator',
        'lost_desc': 'Lost scientific calculator with display cover, left on desk.',
        'found_desc': 'Found scientific calculator on table near study area.',
        'location': 'Central Library - Reading Hall'
    },
    'charger': {
        'category': 'Electronics & Gadgets',
        'default_title': 'Laptop / Mobile Power Adapter & Cable',
        'lost_desc': 'Black/white charging adapter block and cable left plugged into wall socket.',
        'found_desc': 'Found power adapter and charging cord connected to lab outlet.',
        'location': 'Engineering Block B - Computer Labs'
    },
    'bottle': {
        'category': 'Bottles & Containers',
        'default_title': 'Insulated Stainless Steel Water Bottle',
        'lost_desc': 'Water bottle forgotten near sports seating area after workout.',
        'found_desc': 'Found reusable water bottle left behind on bench.',
        'location': 'Indoor Sports Arena & Gymnasium'
    },
    'umbrella': {
        'category': 'Personal Accessories',
        'default_title': 'Compact Foldable Rain Umbrella',
        'lost_desc': 'Collapsible automatic umbrella left in classroom umbrella stand.',
        'found_desc': 'Found compact folding umbrella near facility reception desk.',
        'location': 'Student Activity Center (SAC)'
    },
    'key': {
        'category': 'Keys & Chains',
        'default_title': 'Vehicle / Room Key with Keychain',
        'lost_desc': 'Metal key on ring with keychain lost between parking and main block.',
        'found_desc': 'Found single ignition key on ring near vehicle parking walkway.',
        'location': 'Main Administrative Block'
    }
}

def import_roboflow_dataset(source_path):
    """
    Imports images and labels from a Roboflow export (.zip or folder) into CampusConnect AI.
    """
    print("=" * 70)
    print("CampusConnect AI: Roboflow Dataset Ingestion Pipeline")
    print(f"Source: {source_path}")
    print("=" * 70)

    extract_dir = os.path.join(BASE_DIR, 'dataset', 'roboflow')
    os.makedirs(extract_dir, exist_ok=True)

    # 1. Handle zip file if provided
    if os.path.isfile(source_path) and source_path.endswith('.zip'):
        print(f"[Roboflow] Extracting zip archive: {source_path}...")
        with zipfile.ZipFile(source_path, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)
        search_root = extract_dir
    elif os.path.isdir(source_path):
        search_root = source_path
    else:
        print(f"[Error] Source path {source_path} is neither a valid zip file nor a directory.")
        return False

    # 2. Look for images in train/valid/test or root
    image_extensions = ('*.jpg', '*.jpeg', '*.png', '*.JPG', '*.JPEG', '*.PNG')
    all_images = []
    for ext in image_extensions:
        all_images.extend(glob.glob(os.path.join(search_root, '**', ext), recursive=True))

    if not all_images:
        print(f"[Warning] No images found inside {search_root}.")
        return False

    print(f"[Roboflow] Located {len(all_images)} images from Roboflow dataset.")

    # 3. Detect class names from data.yaml if present
    yaml_path = os.path.join(search_root, 'data.yaml')
    class_names = ['bottle', 'umbrella', 'calculator', 'charger', 'key']
    if os.path.exists(yaml_path):
        try:
            with open(yaml_path, 'r') as yf:
                lines = yf.readlines()
            for line in lines:
                if 'names:' in line:
                    # e.g., names: ['Bottle', 'Umbrella', 'Calculator', 'Charger', 'Key']
                    raw = line.split('names:')[1].strip()
                    import ast
                    parsed = ast.literal_eval(raw)
                    class_names = [str(c).lower() for c in parsed]
                    print(f"[Roboflow] Parsed classes from data.yaml: {class_names}")
        except Exception as e:
            print(f"[Roboflow] Note: Using standard class list ({e})")

    # 4. Target folders
    static_seed_dir = os.path.join(BASE_DIR, 'static', 'uploads', 'seed')
    dataset_img_dir = os.path.join(BASE_DIR, 'dataset', 'images')
    os.makedirs(static_seed_dir, exist_ok=True)
    os.makedirs(dataset_img_dir, exist_ok=True)

    vision = get_vision_matcher()
    nlp = get_nlp_matcher()

    print("\n[Roboflow] Ingesting items into CampusConnect AI database...")
    imported_count = 0

    for idx, img_path in enumerate(all_images[:40], 1):  # Process up to 40 images
        basename = os.path.basename(img_path)
        lower_name = basename.lower()

        # Infer class from filename or parent folder
        detected_class = 'calculator'
        for c in class_names:
            if c in lower_name:
                detected_class = c
                break

        cfg = ROBOFLOW_CATEGORY_MAP.get(detected_class, ROBOFLOW_CATEGORY_MAP['calculator'])
        item_type = 'lost' if idx % 2 != 0 else 'found'
        title = f"{detected_class.capitalize()} ({item_type.capitalize()})"
        desc = cfg['lost_desc'] if item_type == 'lost' else cfg['found_desc']

        # Copy image to static seed and dataset images
        target_name = f"roboflow_{basename}"
        dest_static = os.path.join(static_seed_dir, target_name)
        dest_dataset = os.path.join(dataset_img_dir, target_name)

        shutil.copy2(img_path, dest_static)
        shutil.copy2(img_path, dest_dataset)

        # Insert user & item
        user_name = f"Roboflow Student {idx}"
        user_id = get_or_create_user(user_name, f"student{idx}@campus.edu", f"RF{idx:03d}", "+91 98765 00000")

        item_id = add_item(
            user_id=user_id,
            item_type=item_type,
            title=f"{cfg['default_title']} #{idx}",
            description=desc,
            category=cfg['category'],
            location=cfg['location'],
            date_event='2026-11-21',
            image_path=f"uploads/seed/{target_name}",
            contact_info=f"student{idx}@campus.edu"
        )

        # Compute ResNet-50 and SBERT embeddings
        img_emb = vision.extract_features(dest_static)
        text_emb = nlp.extract_features(title, desc)
        save_embeddings(item_id, text_emb, img_emb)

        imported_count += 1
        print(f"  ✓ [{imported_count}] Imported #{item_id}: {cfg['default_title']} ({detected_class}) -> {item_type}")

    print(f"\n[Roboflow] SUCCESS! {imported_count} images successfully integrated.")
    print("Database and Vector Index updated with Roboflow visual features.")
    return True

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Import Roboflow dataset into CampusConnect AI")
    parser.add_argument('--source', default=os.path.join(BASE_DIR, 'dataset', 'roboflow'), 
                        help="Path to Roboflow zip or extracted directory")
    args = parser.parse_args()
    import_roboflow_dataset(args.source)
