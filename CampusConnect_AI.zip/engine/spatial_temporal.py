import math
from datetime import datetime, date

# Campus Coordinates Map (Simulated Campus Grid in meters relative to Central Library at (0,0))
CAMPUS_COORDINATES = {
    "Central Library - 1st Floor": (0.0, 0.0),
    "Central Library - Reading Hall": (15.0, 10.0),
    "Central Library - Digital Section": (-10.0, 5.0),
    "Engineering Block A - Ground Floor": (80.0, 60.0),
    "Engineering Block B - Computer Labs": (120.0, 90.0),
    "Engineering Block C - Seminar Hall": (150.0, 120.0),
    "Science & Biotech Complex": (200.0, -50.0),
    "Student Cafeteria & Food Court": (40.0, -80.0),
    "Indoor Sports Arena & Gymnasium": (-180.0, -120.0),
    "Student Activity Center (SAC)": (-60.0, -100.0),
    "Auditorium & Convocation Hall": (-120.0, 40.0),
    "Main Administrative Block": (50.0, -30.0),
    "Hostel Mess & Common Room": (-220.0, 150.0),
    "Campus Grounds & Athletic Track": (-250.0, -80.0)
}

def get_location_coordinates(location_name):
    """
    Returns (x, y) coordinates for a location string with fuzzy matching fallback.
    """
    if not location_name:
        return (0.0, 0.0)
    
    loc_clean = location_name.strip()
    if loc_clean in CAMPUS_COORDINATES:
        return CAMPUS_COORDINATES[loc_clean]
    
    # Keyword fallback
    loc_lower = loc_clean.lower()
    for name, coords in CAMPUS_COORDINATES.items():
        if any(token in name.lower() for token in loc_lower.split() if len(token) > 3):
            return coords
            
    return (100.0, 100.0) # Default general distance

def compute_spatial_similarity(loc1, loc2, sigma=150.0):
    """
    Calculates spatial proximity using a Gaussian distance decay function.
    S_loc = exp(- d^2 / (2 * sigma^2))
    """
    if not loc1 or not loc2:
        return 0.50

    p1 = get_location_coordinates(loc1)
    p2 = get_location_coordinates(loc2)

    dist_meters = math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)
    similarity = math.exp(- (dist_meters**2) / (2 * (sigma**2)))
    return float(similarity), round(dist_meters, 1)

def compute_temporal_similarity(date1_str, date2_str, tau_days=30.0):
    """
    Calculates temporal proximity based on elapsed days between event dates.
    S_time = exp(- |delta_days| / tau_days)
    """
    if not date1_str or not date2_str:
        return 0.85, 0

    try:
        if isinstance(date1_str, (datetime, date)):
            d1 = date1_str if isinstance(date1_str, date) else date1_str.date()
        else:
            d1 = datetime.strptime(str(date1_str).split()[0], '%Y-%m-%d').date()

        if isinstance(date2_str, (datetime, date)):
            d2 = date2_str if isinstance(date2_str, date) else date2_str.date()
        else:
            d2 = datetime.strptime(str(date2_str).split()[0], '%Y-%m-%d').date()

        delta_days = abs((d1 - d2).days)
        sim = math.exp(- delta_days / tau_days)
        return float(sim), delta_days
    except Exception:
        return 0.85, 0
