import time
import numpy as np
from database.db_manager import get_candidates_for_matching

class CampusVectorIndex:
    """
    High-Performance In-Memory Vector Search Index for CampusConnect AI.
    Features:
    1. Fast vectorized NumPy matrix dot-product operations for real-time inference.
    2. Modality segregation (Vision 2048-d and NLP 384-d).
    3. Incremental index updates when new reports are submitted.
    """
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(CampusVectorIndex, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self.lost_items = []
        self.found_items = []

        self.lost_text_matrix = np.empty((0, 384), dtype=np.float32)
        self.lost_image_matrix = np.empty((0, 2048), dtype=np.float32)

        self.found_text_matrix = np.empty((0, 384), dtype=np.float32)
        self.found_image_matrix = np.empty((0, 2048), dtype=np.float32)

        self.rebuild_index()
        self._initialized = True

    def rebuild_index(self):
        """
        Loads all active candidate items and stacks their embedding matrices into memory.
        """
        t0 = time.time()
        self.lost_items = get_candidates_for_matching('lost')
        self.found_items = get_candidates_for_matching('found')

        # Build Lost matrices
        self.lost_text_matrix = self._build_matrix(self.lost_items, 'text_embedding', 384)
        self.lost_image_matrix = self._build_matrix(self.lost_items, 'image_embedding', 2048)

        # Build Found matrices
        self.found_text_matrix = self._build_matrix(self.found_items, 'text_embedding', 384)
        self.found_image_matrix = self._build_matrix(self.found_items, 'image_embedding', 2048)

        elapsed_ms = (time.time() - t0) * 1000
        print(f"[VectorIndex] Indexed {len(self.lost_items)} lost items and {len(self.found_items)} found items in {elapsed_ms:.2f} ms.")

    def _build_matrix(self, items, key, dim):
        matrix = []
        for it in items:
            emb = it.get(key)
            if emb is not None and len(emb) == dim:
                matrix.append(emb)
            else:
                matrix.append(np.zeros(dim, dtype=np.float32))
        return np.array(matrix, dtype=np.float32) if matrix else np.empty((0, dim), dtype=np.float32)

    def search_candidates(self, query_item, query_text_emb, query_img_emb, target_type='found', top_k=20):
        """
        Executes fast vectorized batch search against target pool.
        Returns candidate list with computed similarity scores.
        """
        t_start = time.time()

        if target_type == 'found':
            candidates = self.found_items
            text_matrix = self.found_text_matrix
            img_matrix = self.found_image_matrix
        else:
            candidates = self.lost_items
            text_matrix = self.lost_text_matrix
            img_matrix = self.lost_image_matrix

        N = len(candidates)
        if N == 0:
            return [], {"index_search_ms": 0.0, "total_candidates": 0}

        # Vectorized batch text similarities: (N,)
        if query_text_emb is not None and len(text_matrix) > 0:
            text_sims = np.dot(text_matrix, query_text_emb)
            text_sims = np.clip(text_sims, 0.0, 1.0)
        else:
            text_sims = np.zeros(N, dtype=np.float32)

        # Vectorized batch image similarities: (N,)
        has_query_img = query_img_emb is not None
        if has_query_img and len(img_matrix) > 0:
            img_sims = np.dot(img_matrix, query_img_emb)
            img_sims = np.clip(img_sims, 0.0, 1.0)
        else:
            img_sims = np.zeros(N, dtype=np.float32)

        search_ms = (time.time() - t_start) * 1000
        return candidates, text_sims, img_sims, {
            "index_search_ms": round(search_ms, 3),
            "total_candidates": N
        }

# Singleton
_index_instance = None
def get_vector_index():
    global _index_instance
    if _index_instance is None:
        _index_instance = CampusVectorIndex()
    return _index_instance
