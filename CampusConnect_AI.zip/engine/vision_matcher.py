import os
import time
import cv2
import torch
import torch.nn as nn
from torchvision import models, transforms
from PIL import Image
import numpy as np

class VisionMatcher:
    """
    Advanced Computer Vision Feature Extraction & Similarity Engine for CampusConnect AI.
    Integrates:
    1. Deep Transfer Learning with ResNet-50 (Penultimate GAP layer, 2048 dimensions).
    2. OpenCV HSV 3D Color Histogram Profiling (Unit II Color Spaces).
    3. Perceptual Difference Hashing (dHash) for instant duplicate detection.
    """
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(VisionMatcher, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self, device=None):
        if self._initialized:
            return

        if device is None:
            if torch.backends.mps.is_available():
                self.device = torch.device("mps")
            elif torch.cuda.is_available():
                self.device = torch.device("cuda")
            else:
                self.device = torch.device("cpu")
        else:
            self.device = torch.device(device)

        print(f"[VisionMatcher] Initializing ResNet-50 vision backbone on {self.device}...")

        weights = models.ResNet50_Weights.DEFAULT
        base_model = models.resnet50(weights=weights)
        # Sever the final classification layer to tap 2048-d feature space
        base_model.fc = nn.Identity()
        self.model = base_model.to(self.device)
        self.model.eval()

        self.transform = transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            )
        ])

        # In-memory feature cache
        self._embedding_cache = {}
        self._initialized = True
        print(f"[VisionMatcher] ResNet-50 feature extractor ready on {self.device}.")

    def compute_dhash(self, image_input, hash_size=8):
        """
        Computes 64-bit difference hash (dHash) via OpenCV for O(1) duplicate detection.
        """
        try:
            if isinstance(image_input, str):
                img = cv2.imread(image_input, cv2.IMREAD_GRAYSCALE)
            elif isinstance(image_input, np.ndarray):
                img = cv2.cvtColor(image_input, cv2.COLOR_BGR2GRAY) if len(image_input.shape) == 3 else image_input
            elif isinstance(image_input, Image.Image):
                img = np.array(image_input.convert('L'))
            else:
                return None

            if img is None:
                return None

            resized = cv2.resize(img, (hash_size + 1, hash_size))
            diff = resized[:, 1:] > resized[:, :-1]
            return sum([2 ** i for (i, v) in enumerate(diff.flatten()) if v])
        except Exception:
            return None

    def extract_color_histogram(self, image_input, bins=(8, 4, 4)):
        """
        Extracts normalized 3D color histogram in OpenCV HSV color space (Unit II).
        """
        try:
            if isinstance(image_input, str):
                img_bgr = cv2.imread(image_input)
            elif isinstance(image_input, np.ndarray):
                img_bgr = image_input
            elif isinstance(image_input, Image.Image):
                img_bgr = cv2.cvtColor(np.array(image_input), cv2.COLOR_RGB2BGR)
            else:
                return None

            if img_bgr is None:
                return None

            hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
            hist = cv2.calcHist([hsv], [0, 1, 2], None, bins, [0, 180, 0, 256, 0, 256])
            hist = cv2.normalize(hist, hist).flatten()
            return hist.astype(np.float32)
        except Exception:
            return None

    def preprocess_image_cv(self, image_path):
        """
        Loads image with OpenCV, converts BGR to RGB, and returns PIL Image.
        """
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Image not found at path: {image_path}")

        img_bgr = cv2.imread(image_path)
        if img_bgr is None:
            raise ValueError(f"Could not decode image at {image_path}")

        img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
        return Image.fromarray(img_rgb)

    def extract_features(self, image_input):
        """
        Extracts L2-normalized 2048-d feature vector from ResNet-50.
        Returns: numpy.ndarray of shape (2048,) or None.
        """
        if isinstance(image_input, str) and image_input in self._embedding_cache:
            return self._embedding_cache[image_input]

        try:
            if isinstance(image_input, str):
                pil_img = self.preprocess_image_cv(image_input)
            elif isinstance(image_input, Image.Image):
                pil_img = image_input
            elif isinstance(image_input, np.ndarray):
                pil_img = Image.fromarray(cv2.cvtColor(image_input, cv2.COLOR_BGR2RGB))
            else:
                return None

            tensor = self.transform(pil_img).unsqueeze(0).to(self.device)

            with torch.no_grad():
                features = self.model(tensor)
                features = features.squeeze().cpu().numpy()

                norm = np.linalg.norm(features)
                if norm > 1e-7:
                    features = features / norm
                else:
                    features = np.zeros_like(features)

                emb = features.astype(np.float32)
                if isinstance(image_input, str):
                    self._embedding_cache[image_input] = emb
                return emb

        except Exception as e:
            print(f"[VisionMatcher Error] Feature extraction failed: {e}")
            return None

    def compute_similarity(self, emb1, emb2):
        """
        Computes cosine similarity between two 2048-d image embeddings.
        """
        if emb1 is None or emb2 is None:
            return 0.0

        dot = np.dot(emb1, emb2)
        norm1 = np.linalg.norm(emb1)
        norm2 = np.linalg.norm(emb2)

        if norm1 < 1e-7 or norm2 < 1e-7:
            return 0.0

        cos_sim = dot / (norm1 * norm2)
        return float(np.clip(cos_sim, 0.0, 1.0))

    def compute_batch_similarities(self, query_emb, candidate_matrix):
        """
        Fast vectorized batch cosine similarity: S = Q · C^T
        query_emb: (2048,)
        candidate_matrix: (N, 2048)
        Returns: (N,) similarity vector in [0.0, 1.0]
        """
        if query_emb is None or candidate_matrix is None or len(candidate_matrix) == 0:
            return np.array([])

        sims = np.dot(candidate_matrix, query_emb)
        return np.clip(sims, 0.0, 1.0)

# Singleton
_vision_instance = None
def get_vision_matcher():
    global _vision_instance
    if _vision_instance is None:
        _vision_instance = VisionMatcher()
    return _vision_instance
