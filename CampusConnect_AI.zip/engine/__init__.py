"""
CampusConnect AI Matching Engines:
- VisionMatcher: ResNet-50 2048-d feature extraction & Cosine similarity (CV)
- NLPMatcher: Pretrained Transformer 384-d dense embeddings (NLP)
- MultimodalMatcher: Ensemble weighted fusion & ranking
"""
from engine.vision_matcher import VisionMatcher, get_vision_matcher
from engine.nlp_matcher import NLPMatcher, get_nlp_matcher
from engine.multimodal_matcher import MultimodalMatcher, get_multimodal_matcher
