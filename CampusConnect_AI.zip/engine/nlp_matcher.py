import os
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
import re
import numpy as np

class NLPMatcher:
    """
    Advanced Natural Language Processing Semantic Engine for CampusConnect AI.
    Integrates:
    1. Pretrained Sentence-Transformers ('all-MiniLM-L6-v2') for dense 384-dim embeddings.
    2. Rule-based entity & brand/color keyword extraction (Units IV & V).
    3. Fast vectorized batch similarity calculations.
    4. In-memory embedding cache for high-throughput responses.
    """
    _instance = None

    KNOWN_BRANDS = {
        'casio', 'apple', 'milton', 'samsung', 'hp', 'dell', 'lenovo', 
        'boat', 'sony', 'oneplus', 'nike', 'adidas', 'wildcraft', 'fastrack'
    }
    KNOWN_COLORS = {
        'black', 'white', 'blue', 'red', 'green', 'grey', 'gray', 'silver', 
        'gold', 'pink', 'yellow', 'purple', 'brown', 'matte', 'metallic'
    }

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(NLPMatcher, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self, model_name="all-MiniLM-L6-v2"):
        if self._initialized:
            return

        self.model_name = model_name
        self.transformer_model = None
        self._embedding_cache = {}

        print(f"[NLPMatcher] Loading Transformer Semantic Encoder ({model_name})...")
        try:
            from sentence_transformers import SentenceTransformer
            self.transformer_model = SentenceTransformer(model_name)
            print(f"[NLPMatcher] SentenceTransformer '{model_name}' loaded successfully (384-dim).")
        except Exception as e:
            print(f"[NLPMatcher Warning] Could not load SentenceTransformer ({e}). Using dense projection fallback.")

        self._initialized = True

    def preprocess_text(self, text):
        """
        Cleans and standardizes student text descriptions (Unit IV: Text Preprocessing).
        """
        if not text or not isinstance(text, str):
            return ""
        cleaned = text.lower()
        cleaned = re.sub(r'[^a-z0-9\s\-_]', ' ', cleaned)
        return re.sub(r'\s+', ' ', cleaned).strip()

    def extract_entities(self, text):
        """
        Extracts structured domain entities: brands, colors, and model alphanumeric codes.
        """
        cleaned = self.preprocess_text(text)
        tokens = set(cleaned.split())

        brands = tokens.intersection(self.KNOWN_BRANDS)
        colors = tokens.intersection(self.KNOWN_COLORS)
        
        # Alphanumeric model numbers like 'fx-991ex', 'fx-82ms', 'airpods'
        models_found = set(re.findall(r'\b[a-z]{1,4}[-_]?[0-9]{2,4}[a-z]{0,3}\b', cleaned))

        return {
            'brands': list(brands),
            'colors': list(colors),
            'models': list(models_found)
        }

    def extract_features(self, title, description=""):
        """
        Extracts dense 384-dimensional contextual embedding vector.
        """
        combined = f"{title}. {description}".strip()
        cleaned = self.preprocess_text(combined)
        if not cleaned:
            return None

        if cleaned in self._embedding_cache:
            return self._embedding_cache[cleaned]

        if self.transformer_model is not None:
            try:
                emb = self.transformer_model.encode(cleaned, normalize_embeddings=True)
                emb = emb.astype(np.float32)
                self._embedding_cache[cleaned] = emb
                return emb
            except Exception as e:
                print(f"[NLPMatcher Error] Transformer encoding error: {e}")

        # Fallback projection
        emb = self._generate_dense_fallback_embedding(cleaned)
        self._embedding_cache[cleaned] = emb
        return emb

    def _generate_dense_fallback_embedding(self, text, dim=384):
        vec = np.zeros(dim, dtype=np.float32)
        words = text.split()
        for i, word in enumerate(words):
            h = hash(word) % dim
            weight = 1.0 / (1.0 + 0.1 * i)
            vec[h] += weight

        norm = np.linalg.norm(vec)
        if norm > 1e-7:
            vec = vec / norm
        return vec

    def compute_similarity(self, emb1, emb2):
        """
        Cosine similarity between two 384-d semantic text vectors.
        """
        if emb1 is None or emb2 is None:
            return 0.0

        dot = np.dot(emb1, emb2)
        norm1 = np.linalg.norm(emb1)
        norm2 = np.linalg.norm(emb2)

        if norm1 < 1e-7 or norm2 < 1e-7:
            return 0.0

        sim = dot / (norm1 * norm2)
        return float(np.clip(sim, 0.0, 1.0))

    def compute_batch_similarities(self, query_emb, candidate_matrix):
        """
        Fast vectorized batch cosine similarity: S = Q · C^T
        query_emb: (384,)
        candidate_matrix: (N, 384)
        """
        if query_emb is None or candidate_matrix is None or len(candidate_matrix) == 0:
            return np.array([])
        sims = np.dot(candidate_matrix, query_emb)
        return np.clip(sims, 0.0, 1.0)

# Singleton
_nlp_instance = None
def get_nlp_matcher():
    global _nlp_instance
    if _nlp_instance is None:
        _nlp_instance = NLPMatcher()
    return _nlp_instance
