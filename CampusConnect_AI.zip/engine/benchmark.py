"""
CampusConnect AI - Standalone AI Benchmark & Viva Verification Suite
Demonstrates Computer Vision (ResNet-50) & NLP (Sentence-Transformers) for CAB213.
"""
import time
import os
import sys
import numpy as np

# Add project root
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from engine.vision_matcher import get_vision_matcher
from engine.nlp_matcher import get_nlp_matcher
from engine.multimodal_matcher import get_multimodal_matcher
from sample_data.seed_data import generate_mock_image
from config import BASE_DIR, UPLOAD_FOLDER

def run_benchmark():
    print("=" * 75)
    print("   CampusConnect AI: CAB213 Applied AI Model Benchmark & Viva Suite")
    print("=" * 75)

    # 1. Computer Vision Feature Extraction (ResNet-50)
    print("\n[1/3] Testing Computer Vision Pipeline (OpenCV + ResNet-50)...")
    vision = get_vision_matcher()

    p1 = os.path.join(BASE_DIR, 'static', 'uploads', 'seed', 'calc_lost.jpg')
    p2 = os.path.join(BASE_DIR, 'static', 'uploads', 'seed', 'calc_found.jpg')
    p3 = os.path.join(BASE_DIR, 'static', 'uploads', 'seed', 'bottle_black.jpg')
    p_casio82 = os.path.join(BASE_DIR, 'static', 'uploads', 'seed', 'calc_casio82.jpg')

    t0 = time.time()
    emb1 = vision.extract_features(p1)
    t_vision = time.time() - t0

    emb2 = vision.extract_features(p2)
    emb3 = vision.extract_features(p3)

    print(f"  ✓ Device: {vision.device}")
    print(f"  ✓ ResNet-50 Output Dimension: {emb1.shape} (Expected: 2048)")
    print(f"  ✓ L2-Norm Verification: ||v|| = {np.linalg.norm(emb1):.4f} (Expected: 1.0000)")
    print(f"  ✓ Feature Extraction Latency: {t_vision*1000:.2f} ms")

    sim_v_pos = vision.compute_similarity(emb1, emb2)
    sim_v_neg = vision.compute_similarity(emb1, emb3)
    print(f"  ✓ Positive Image Pair Cosine Sim: {sim_v_pos*100:.1f}%")
    print(f"  ✓ Negative Image Pair Cosine Sim: {sim_v_neg*100:.1f}%")

    # 2. NLP Semantic Embedding Pipeline
    print("\n[2/3] Testing NLP Semantic Embedding Pipeline (Sentence Transformers)...")
    nlp = get_nlp_matcher()

    text_lost = "Casio scientific calculator with solar panel, left in library reading hall"
    text_found_match = "Black scientific calculator with dual power solar cell found on desk"
    text_found_partial = "Casio fx-82MS calculator with grey casing"
    text_found_neg = "Black stainless steel water bottle with silver cap"

    t0 = time.time()
    t_emb1 = nlp.extract_features("Scientific Calculator", text_lost)
    t_nlp = time.time() - t0

    t_emb2 = nlp.extract_features("Scientific Calculator", text_found_match)
    t_emb3 = nlp.extract_features("Casio Calculator", text_found_partial)
    t_emb4 = nlp.extract_features("Water Bottle", text_found_neg)

    print(f"  ✓ NLP Embedding Dimension: {t_emb1.shape} (Expected: 384)")
    print(f"  ✓ L2-Norm Verification: ||t|| = {np.linalg.norm(t_emb1):.4f} (Expected: 1.0000)")
    print(f"  ✓ Encoding Latency: {t_nlp*1000:.2f} ms")

    sim_t_high = nlp.compute_similarity(t_emb1, t_emb2)
    sim_t_mid = nlp.compute_similarity(t_emb1, t_emb3)
    sim_t_low = nlp.compute_similarity(t_emb1, t_emb4)

    print(f"  ✓ Semantic Sim (Same Item, Different Words): {sim_t_high*100:.1f}%")
    print(f"  ✓ Semantic Sim (Same Category, Diff Model): {sim_t_mid*100:.1f}%")
    print(f"  ✓ Semantic Sim (Different Category - Bottle): {sim_t_low*100:.1f}%")

    # 3. Multimodal Ensemble Ranking Output (Matches Proposal Section 6)
    print("\n[3/3] Multimodal Fusion & Ranking Verification...")
    multimodal = get_multimodal_matcher()

    lost_query = {
        'title': 'Casio fx-991EX Scientific Calculator',
        'description': text_lost,
        'location': 'Central Library - Reading Hall',
        'image_path': p1
    }

    candidates = [
        {
            'title': 'Black Scientific Calculator',
            'description': text_found_match,
            'location': 'Central Library - 1st Floor',
            'image_path': p2
        },
        {
            'title': 'Casio fx-82MS Calculator',
            'description': text_found_partial,
            'location': 'Engineering Block B - Computer Labs',
            'image_path': p_casio82
        },
        {
            'title': 'Black Water Bottle',
            'description': text_found_neg,
            'location': 'Student Cafeteria & Food Court',
            'image_path': p3
        }
    ]

    print("\n" + "-" * 75)
    print(f"{'Found Item Candidate':<28} | {'Image Sim':<10} | {'Text Sim':<10} | {'Loc Sim':<8} | {'Total Match'}")
    print("-" * 75)

    for cand in candidates:
        m = multimodal.match_pair(lost_query, cand)
        print(f"{cand['title']:<28} | {m['vision_percentage']:>8}% | {m['text_percentage']:>8}% | {m['location_percentage']:>6}% | {m['total_percentage']:>9}% ({m['confidence']})")

    print("-" * 75)
    print("\n[Benchmark Complete] All syllabus components verified successfully!\n")

if __name__ == '__main__':
    run_benchmark()
