import os
import torch
import torch.nn as nn
from torchvision import models
from PIL import Image
import numpy as np

# Mapping ImageNet class tokens to CampusConnect AI & Roboflow Categories
CATEGORY_MAPPINGS = [
    # Roboflow Category 1: Calculator
    (['calculator', 'hand-held computer', 'slide rule'], 'Stationery & Calculators', 'Calculator (Roboflow Class)'),
    
    # Roboflow Category 2: Bottle
    (['water bottle', 'pop bottle', 'beer bottle', 'wine bottle', 'whiskey jug', 'water jug', 'pitcher', 'cocktail shaker'], 'Bottles & Containers', 'Bottle (Roboflow Class)'),
    
    # Roboflow Category 3: Umbrella
    (['umbrella'], 'Personal Accessories', 'Umbrella (Roboflow Class)'),
    
    # Roboflow Category 4: Charger / Electronics
    (['cellular telephone', 'mobile phone', 'modem', 'mouse', 'laptop', 'notebook computer', 'hard disc', 'plug', 'switch', 'power drill'], 'Electronics & Gadgets', 'Charger / Electronics (Roboflow Class)'),
    
    # Roboflow Category 5: Key / Lock
    (['padlock', 'combination lock', 'chain', 'buckle', 'safe'], 'Keys & Chains', 'Key / Lock (Roboflow Class)'),
    
    # Additional Campus Categories
    (['backpack', 'knapsack', 'duffel bag', 'mailbag'], 'Bags & Backpacks', 'Backpack / Bag'),
    (['wallet', 'purse', 'money bag', 'packet'], 'Wallets & Cards', 'Wallet / Cardholder'),
    (['sunglasses', 'sunglass', 'spectacles'], 'Eyewear & Accessories', 'Eyewear / Spectacles'),
    (['notebook', 'book jacket', 'comic book', 'binder'], 'Books & Notes', 'Book / Notebook')
]

class ObjectDetector:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(ObjectDetector, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        if torch.backends.mps.is_available():
            self.device = torch.device("mps")
        elif torch.cuda.is_available():
            self.device = torch.device("cuda")
        else:
            self.device = torch.device("cpu")

        print(f"[ObjectDetector] Loading Pretrained Vision Classifier on {self.device}...")
        self.weights = models.ResNet50_Weights.DEFAULT
        self.model = models.resnet50(weights=self.weights).to(self.device)
        self.model.eval()
        self.preprocess = self.weights.transforms()
        self.categories = self.weights.meta['categories']
        self._initialized = True

    def detect_category(self, image_input):
        """
        Predicts object category from image, aligning with Roboflow classes.
        Returns: { 'category': str, 'detected_object': str, 'confidence': float, 'top_classes': list }
        """
        try:
            if isinstance(image_input, str):
                img = Image.open(image_input).convert('RGB')
            elif isinstance(image_input, Image.Image):
                img = image_input.convert('RGB')
            else:
                return None

            batch = self.preprocess(img).unsqueeze(0).to(self.device)
            with torch.no_grad():
                logits = self.model(batch)
                probabilities = torch.nn.functional.softmax(logits, dim=1)[0]

            top5_prob, top5_catid = torch.topk(probabilities, 5)
            top_classes = [
                {'class': self.categories[catid.item()], 'confidence': round(prob.item() * 100, 1)}
                for prob, catid in zip(top5_prob, top5_catid)
            ]

            # Match top predictions against our Roboflow & Campus mappings
            for item in top_classes:
                class_str = item['class'].lower()
                for triggers, campus_cat, display_name in CATEGORY_MAPPINGS:
                    if any(t in class_str for t in triggers):
                        return {
                            'success': True,
                            'category': campus_cat,
                            'detected_object': display_name,
                            'confidence': item['confidence'],
                            'imagenet_class': item['class'],
                            'top_classes': top_classes
                        }

            # Default fallback if no specific campus class matched with high confidence
            best_guess = top_classes[0]['class'].replace('_', ' ').capitalize()
            return {
                'success': True,
                'category': 'Electronics & Gadgets',
                'detected_object': best_guess,
                'confidence': top_classes[0]['confidence'],
                'imagenet_class': top_classes[0]['class'],
                'top_classes': top_classes
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}

_detector_instance = None
def get_object_detector():
    global _detector_instance
    if _detector_instance is None:
        _detector_instance = ObjectDetector()
    return _detector_instance
