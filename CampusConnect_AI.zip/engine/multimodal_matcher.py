import os
import time
import numpy as np

from config import (
    BASE_DIR,
    WEIGHT_IMAGE, WEIGHT_TEXT, WEIGHT_LOCATION,
    WEIGHT_TEXT_ONLY_TEXT, WEIGHT_TEXT_ONLY_LOC,
    THRESHOLD_HIGH, THRESHOLD_MEDIUM, THRESHOLD_LOW
)
from engine.vision_matcher import get_vision_matcher
from engine.nlp_matcher import get_nlp_matcher
from engine.spatial_temporal import compute_spatial_similarity, compute_temporal_similarity

class MultimodalMatcher:
    """
    Multimodal Intelligent Fusion & Ranking Engine (Unit VI: Integrated Applications).
    Integrates:
    - Computer Vision: ResNet-50 GAP 2048-d feature space + Color profile.
    - NLP: Sentence-Transformers 384-d dense embeddings + Brand/Model Entity alignment.
    - Spatio-Temporal: Campus topological Gaussian decay + Temporal decay.
    - Detailed latency profiling for real-time observability.
    """
    def __init__(self):
        self.vision_matcher = get_vision_matcher()
        self.nlp_matcher = get_nlp_matcher()

    def compute_location_similarity(self, loc1, loc2):
        """
        Calculates spatial similarity using campus graph distance.
        """
        sim, dist_meters = compute_spatial_similarity(loc1, loc2)
        return sim

    def match_pair(self, item1, item2, emb1=None, emb2=None):
        """
        Calculates multimodal match scores between two items with latency profiling.
        """
        t_start = time.time()
        timings = {}

        # 1. NLP Semantic Embeddings
        t_nlp_start = time.time()
        t_emb1 = emb1[0] if emb1 else None
        t_emb2 = emb2[0] if emb2 else None

        if t_emb1 is None:
            t_emb1 = self.nlp_matcher.extract_features(item1.get('title', ''), item1.get('description', ''))
        if t_emb2 is None:
            t_emb2 = self.nlp_matcher.extract_features(item2.get('title', ''), item2.get('description', ''))

        text_score = self.nlp_matcher.compute_similarity(t_emb1, t_emb2)

        # Entity bonus check (e.g., both explicitly mention 'Casio' or 'AirPods')
        ent1 = self.nlp_matcher.extract_entities(f"{item1.get('title', '')} {item1.get('description', '')}")
        ent2 = self.nlp_matcher.extract_entities(f"{item2.get('title', '')} {item2.get('description', '')}")
        
        shared_brands = set(ent1['brands']).intersection(set(ent2['brands']))
        shared_models = set(ent1['models']).intersection(set(ent2['models']))
        if shared_models:
            text_score = min(1.0, text_score + 0.15)
        elif shared_brands:
            text_score = min(1.0, text_score + 0.08)

        timings['nlp_latency_ms'] = round((time.time() - t_nlp_start) * 1000, 2)

        # 2. Vision Embeddings
        t_vis_start = time.time()
        img_emb1 = emb1[1] if emb1 else None
        img_emb2 = emb2[1] if emb2 else None

        has_both_images = False
        vision_score = 0.0

        if img_emb1 is not None and img_emb2 is not None:
            vision_score = self.vision_matcher.compute_similarity(img_emb1, img_emb2)
            has_both_images = True
        elif item1.get('image_path') and item2.get('image_path'):
            def resolve_img_path(p):
                if not p:
                    return None
                if os.path.isabs(p) and os.path.exists(p):
                    return p
                cand = os.path.join(BASE_DIR, 'static', p)
                if os.path.exists(cand):
                    return cand
                if os.path.exists(p):
                    return p
                return p

            if img_emb1 is None:
                img_emb1 = self.vision_matcher.extract_features(resolve_img_path(item1['image_path']))
            if img_emb2 is None:
                img_emb2 = self.vision_matcher.extract_features(resolve_img_path(item2['image_path']))
            if img_emb1 is not None and img_emb2 is not None:
                vision_score = self.vision_matcher.compute_similarity(img_emb1, img_emb2)
                has_both_images = True

        timings['vision_latency_ms'] = round((time.time() - t_vis_start) * 1000, 2)

        # 3. Spatio-Temporal Modeling
        loc_score, dist_m = compute_spatial_similarity(
            item1.get('location', ''),
            item2.get('location', '')
        )
        time_score, days_diff = compute_temporal_similarity(
            item1.get('date_event', ''),
            item2.get('date_event', '')
        )

        # Combine spatial and temporal into contextual score
        context_score = 0.80 * loc_score + 0.20 * time_score

        # 4. Multimodal Fusion Ensemble
        if has_both_images:
            total_score = (
                WEIGHT_IMAGE * vision_score +
                WEIGHT_TEXT * text_score +
                WEIGHT_LOCATION * context_score
            )
        else:
            total_score = (
                WEIGHT_TEXT_ONLY_TEXT * text_score +
                WEIGHT_TEXT_ONLY_LOC * context_score
            )

        timings['total_pipeline_ms'] = round((time.time() - t_start) * 1000, 2)

        # Confidence categorization
        if total_score >= THRESHOLD_HIGH:
            confidence = "High Match (Likely Same Belonging)"
            badge_class = "success"
        elif total_score >= THRESHOLD_MEDIUM:
            confidence = "Moderate Match (Strong Resemblance)"
            badge_class = "warning"
        elif total_score >= THRESHOLD_LOW:
            confidence = "Possible Match (Partial Overlap)"
            badge_class = "info"
        else:
            confidence = "Low Resemblance"
            badge_class = "secondary"

        explanation = self._generate_explanation(
            has_both_images, total_score, vision_score, text_score, loc_score,
            item1.get('location', ''), item2.get('location', ''),
            dist_m, shared_brands, shared_models
        )

        return {
            'total_score': round(float(total_score), 4),
            'total_percentage': int(round(total_score * 100)),
            'vision_score': round(float(vision_score), 4),
            'vision_percentage': int(round(vision_score * 100)),
            'text_score': round(float(text_score), 4),
            'text_percentage': int(round(text_score * 100)),
            'location_score': round(float(loc_score), 4),
            'location_percentage': int(round(loc_score * 100)),
            'distance_meters': dist_m,
            'days_difference': days_diff,
            'has_both_images': has_both_images,
            'confidence': confidence,
            'badge_class': badge_class,
            'explanation': explanation,
            'timings': timings
        }

    def _generate_explanation(self, has_both_images, total_score, vision_score, text_score, loc_score, loc1, loc2, dist_m=0, brands=None, models=None):
        parts = []
        if models:
            parts.append(f"Identified matching model identifier: {', '.join(models)}")
        elif brands:
            parts.append(f"Verified brand alignment: {', '.join(brands)}")

        if has_both_images:
            if vision_score >= 0.75:
                parts.append(f"Strong visual resemblance ({int(vision_score*100)}%) in physical appearance & color profile")
            elif vision_score >= 0.45:
                parts.append(f"Moderate visual overlap ({int(vision_score*100)}%)")
            else:
                parts.append(f"Low visual similarity ({int(vision_score*100)}%)")

        if text_score >= 0.70:
            parts.append(f"High semantic description correspondence ({int(text_score*100)}%)")
        elif text_score >= 0.40:
            parts.append(f"Contextual description overlap ({int(text_score*100)}%)")

        if dist_m <= 30:
            parts.append(f"Both reported in immediate proximity (~{int(dist_m)}m apart)")
        elif dist_m <= 100:
            parts.append(f"Locations within adjacent campus zones (~{int(dist_m)}m)")

        if not parts:
            return "General category alignment with modest overall similarity."

        return "; ".join(parts).capitalize() + "."

    def rank_candidates_for_item(self, query_item, query_emb, candidate_items, min_score=0.20):
        """
        Ranks all candidate items against query_item in descending order of total_score.
        """
        results = []
        for cand in candidate_items:
            cand_emb = (cand.get('text_embedding'), cand.get('image_embedding'))
            match_metrics = self.match_pair(query_item, cand, query_emb, cand_emb)

            if match_metrics['total_score'] >= min_score:
                results.append({
                    'candidate': cand,
                    'metrics': match_metrics
                })

        results.sort(key=lambda x: x['metrics']['total_score'], reverse=True)
        return results

# Singleton
_multimodal_instance = None
def get_multimodal_matcher():
    global _multimodal_instance
    if _multimodal_instance is None:
        _multimodal_instance = MultimodalMatcher()
    return _multimodal_instance
