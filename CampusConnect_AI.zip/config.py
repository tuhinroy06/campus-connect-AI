import os
from dotenv import load_dotenv

# Load environment variables from .env if present
load_dotenv()

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# Storage Paths
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads')
DATABASE_PATH = os.path.join(BASE_DIR, 'database', 'campusconnect.db')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp', 'gif'}

# Secret Key for Flask sessions
SECRET_KEY = os.environ.get('SECRET_KEY', 'campusconnect_ai_secret_key_cab213_2026')

# Administrator Credentials
ADMIN_USERNAME = os.environ.get('ADMIN_USERNAME', 'admin')
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'admin123')

# Supabase Cloud Database (PostgreSQL + pgvector)
SUPABASE_URL = os.environ.get('SUPABASE_URL', '')
SUPABASE_KEY = os.environ.get('SUPABASE_KEY', '')
USE_SUPABASE = bool(SUPABASE_URL and SUPABASE_KEY)

# Multimodal Fusion Weights (Default for Multimodal Reports)
WEIGHT_IMAGE = 0.50
WEIGHT_TEXT = 0.35
WEIGHT_LOCATION = 0.15

# Weights when no image is provided (Text + Location fallback)
WEIGHT_TEXT_ONLY_TEXT = 0.70
WEIGHT_TEXT_ONLY_LOC = 0.30

# High / Medium match thresholds
THRESHOLD_HIGH = 0.75
THRESHOLD_MEDIUM = 0.50
THRESHOLD_LOW = 0.30

# Predefined Campus Locations for Auto-complete & Proximity
CAMPUS_LOCATIONS = [
    "Central Library - 1st Floor",
    "Central Library - Reading Hall",
    "Central Library - Digital Section",
    "Engineering Block A - Ground Floor",
    "Engineering Block B - Computer Labs",
    "Engineering Block C - Seminar Hall",
    "Science & Biotech Complex",
    "Student Cafeteria & Food Court",
    "Indoor Sports Arena & Gymnasium",
    "Student Activity Center (SAC)",
    "Auditorium & Convocation Hall",
    "Main Administrative Block",
    "Hostel Mess & Common Room",
    "Campus Grounds & Athletic Track"
]

ITEM_CATEGORIES = [
    "Electronics & Gadgets",
    "Stationery & Calculators",
    "ID Cards & Wallets",
    "Bottles & Containers",
    "Bags & Backpacks",
    "Books & Notebooks",
    "Clothing & Accessories",
    "Keys & Keychains",
    "Other"
]
