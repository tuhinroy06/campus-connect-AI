import os
import sys
import builtins
import uuid
import time
from datetime import date
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
import torch
import numpy as np

# Prevent OSError: [Errno 5] Input/output error when stdout is detached/closed
_real_print = builtins.print
def safe_print(*args, **kwargs):
    try:
        _real_print(*args, **kwargs)
    except (OSError, IOError):
        pass
builtins.print = safe_print

import config
from database.db_manager import (
    init_db, get_or_create_user, add_item, get_item, get_items,
    save_embeddings, get_item_embeddings, get_candidates_for_matching,
    record_match, get_matches_for_item, get_all_matches,
    update_item_status, get_dashboard_stats
)
from engine.vision_matcher import get_vision_matcher
from engine.nlp_matcher import get_nlp_matcher
from engine.multimodal_matcher import get_multimodal_matcher
from engine.vector_index import get_vector_index

app = Flask(__name__)
app.secret_key = config.SECRET_KEY
app.config['UPLOAD_FOLDER'] = config.UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB max

os.makedirs(config.UPLOAD_FOLDER, exist_ok=True)

@app.template_filter('img_url')
def img_url_filter(path):
    if not path:
        return ''
    cleaned = path.replace('\\', '/').strip('/')
    if cleaned.startswith('static/'):
        cleaned = cleaned[len('static/'):]
    if cleaned.startswith('uploads/'):
        return url_for('static', filename=cleaned)
    return url_for('static', filename=f'uploads/{cleaned}')

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in config.ALLOWED_EXTENSIONS

# =========================================================================
# Web UI Routes
# =========================================================================

@app.route('/')
def index():
    stats = get_dashboard_stats()
    return render_template('index.html', stats=stats)

@app.route('/report/<item_type>', methods=['GET', 'POST'])
def report_item(item_type):
    if item_type not in ('lost', 'found'):
        flash("Invalid report type.", "error")
        return redirect(url_for('index'))

    if request.method == 'POST':
        submitted_type = request.form.get('item_type', item_type).strip()
        if submitted_type in ('lost', 'found'):
            item_type = submitted_type

        title = request.form.get('title', '').strip()
        category = request.form.get('category', '').strip()
        location = request.form.get('location', '').strip()
        date_event = request.form.get('date_event', '').strip()
        description = request.form.get('description', '').strip()
        reporter_name = request.form.get('reporter_name', '').strip()
        student_id = request.form.get('student_id', '').strip()
        email = request.form.get('email', '').strip()
        phone = request.form.get('phone', '').strip()

        if not title or not description or not location or not email:
            flash("Please fill in all mandatory fields.", "error")
            return redirect(request.url)

        # 1. User
        user_id = get_or_create_user(name=reporter_name, email=email, student_id=student_id, phone=phone)

        # 2. File Upload
        image_rel_path = None
        full_image_path = None
        if 'image' in request.files:
            file = request.files['image']
            if file and file.filename != '' and allowed_file(file.filename):
                ext = file.filename.rsplit('.', 1)[1].lower()
                unique_name = f"{item_type}_{uuid.uuid4().hex[:10]}.{ext}"
                save_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_name)
                file.save(save_path)
                image_rel_path = f"uploads/{unique_name}"
                full_image_path = save_path

        # 3. Insert Database Item
        item_id = add_item(
            user_id=user_id,
            item_type=item_type,
            title=title,
            description=description,
            category=category,
            location=location,
            date_event=date_event or str(date.today()),
            image_path=image_rel_path,
            contact_info=phone or email
        )

        # 4. Extract Deep Multimodal Features
        nlp = get_nlp_matcher()
        vision = get_vision_matcher()

        text_embedding = nlp.extract_features(title, description)
        image_embedding = None
        if full_image_path and os.path.exists(full_image_path):
            image_embedding = vision.extract_features(full_image_path)

        # Cache in SQLite
        save_embeddings(item_id, text_embedding, image_embedding)

        # 5. Invalidate & Sync Vector Index
        vector_index = get_vector_index()
        vector_index.rebuild_index()

        # 6. Auto-Matching Pipeline
        candidate_type = 'found' if item_type == 'lost' else 'lost'
        candidates = get_candidates_for_matching(candidate_type=candidate_type, exclude_id=item_id)

        multimodal = get_multimodal_matcher()
        query_item = {
            'id': item_id,
            'title': title,
            'description': description,
            'location': location,
            'date_event': date_event,
            'image_path': full_image_path
        }
        query_emb = (text_embedding, image_embedding)

        matched_count = 0
        for cand in candidates:
            cand_emb = (cand.get('text_embedding'), cand.get('image_embedding'))
            metrics = multimodal.match_pair(query_item, cand, query_emb, cand_emb)

            lost_id = item_id if item_type == 'lost' else cand['id']
            found_id = cand['id'] if item_type == 'lost' else item_id

            record_match(
                lost_item_id=lost_id,
                found_item_id=found_id,
                total_score=metrics['total_score'],
                vision_score=metrics['vision_score'],
                text_score=metrics['text_score'],
                location_score=metrics['location_score']
            )
            if metrics['total_score'] >= config.THRESHOLD_MEDIUM:
                matched_count += 1

        report_label = "Lost item report" if item_type == 'lost' else "Found item deposit"
        flash(
            f"Your {report_label} has been logged. Our matching engine identified {matched_count} potential match(es).",
            "success"
        )
        return redirect(url_for('view_item_matches', item_id=item_id))

    return render_template(
        'report_form.html',
        item_type=item_type,
        categories=config.ITEM_CATEGORIES,
        locations=config.CAMPUS_LOCATIONS,
        current_date=str(date.today())
    )

@app.route('/item/<int:item_id>/matches')
def view_item_matches(item_id):
    item = get_item(item_id)
    if not item:
        flash("Item not found.", "error")
        return redirect(url_for('index'))

    if item.get('status') == 'resolved':
        flash("This item has already been matched and marked as reunited.", "info")
        return redirect(url_for('matches_feed'))

    comp_type = 'found' if item['type'] == 'lost' else 'lost'
    candidates = get_candidates_for_matching(candidate_type=comp_type, exclude_id=item_id)

    text_emb, img_emb = get_item_embeddings(item_id)
    query_emb = (text_emb, img_emb)

    multimodal = get_multimodal_matcher()
    ranked_results = multimodal.rank_candidates_for_item(
        query_item=item,
        query_emb=query_emb,
        candidate_items=candidates,
        min_score=config.THRESHOLD_LOW
    )

    return render_template('item_matches.html', item=item, matches=ranked_results)

@app.route('/matches')
def matches_feed():
    matches = get_all_matches(min_score=config.THRESHOLD_LOW, limit=50)
    return render_template('matches_feed.html', matches=matches)

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('is_admin'):
            flash("Please sign in with administrator credentials to access the admin portal.", "warning")
            return redirect(url_for('admin_login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if session.get('is_admin'):
        return redirect(url_for('admin_panel'))
    
    next_url = request.args.get('next') or request.form.get('next') or url_for('admin_panel')
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        
        if username == config.ADMIN_USERNAME and password == config.ADMIN_PASSWORD:
            session['is_admin'] = True
            session['admin_user'] = username
            flash(f"Welcome back, Administrator ({username})!", "success")
            return redirect(next_url)
        else:
            flash("Invalid administrator credentials. Please check your username and password.", "error")
            
    return render_template('admin_login.html', next_url=next_url)

@app.route('/admin/logout')
def admin_logout():
    session.pop('is_admin', None)
    session.pop('admin_user', None)
    flash("You have been successfully signed out of the admin portal.", "info")
    return redirect(url_for('index'))

@app.route('/item/<int:item_id>/resolve', methods=['POST'])
@admin_required
def resolve_item(item_id):
    update_item_status(item_id, 'resolved')
    matched_id = request.form.get('matched_item_id')
    if matched_id:
        update_item_status(int(matched_id), 'resolved')
    get_vector_index().rebuild_index()
    flash("Item successfully verified & marked as reunited! It has been removed from active feeds.", "success")
    return redirect(url_for('matches_feed'))

@app.route('/admin')
@admin_required
def admin_panel():
    all_items = get_items(limit=100)
    return render_template('admin.html', items=all_items)

@app.route('/admin/seed')
@admin_required
def seed_database_route():
    try:
        from sample_data.seed_data import seed_database
        seed_database()
        get_vector_index().rebuild_index()
        flash("Database successfully seeded with realistic campus items and AI embeddings!", "success")
    except Exception as e:
        flash(f"Error seeding database: {str(e)}", "error")
    return redirect(url_for('admin_panel'))

# =========================================================================
# High-Performance REST API V1 (Production & Viva Gold Standard)
# =========================================================================

@app.route('/api/v1/health', methods=['GET'])
def api_health():
    """
    Returns engine device status (MPS/CUDA/CPU), vector memory usage, and health.
    """
    device_name = "mps" if torch.backends.mps.is_available() else ("cuda" if torch.cuda.is_available() else "cpu")
    v_index = get_vector_index()
    return jsonify({
        'status': 'healthy',
        'service': 'CampusConnect AI Engine',
        'device': device_name,
        'torch_version': torch.__version__,
        'index_stats': {
            'lost_items_indexed': len(v_index.lost_items),
            'found_items_indexed': len(v_index.found_items),
            'vision_feature_dims': 2048,
            'nlp_feature_dims': 384
        }
    })

@app.route('/api/v1/search', methods=['POST'])
def api_search():
    """
    Multimodal search API: searches the index by title, description, and optional location.
    """
    t0 = time.time()
    data = request.get_json(silent=True) or request.form.to_dict()

    query_text = data.get('query', '').strip()
    target_type = data.get('target_type', 'found')
    top_k = int(data.get('top_k', 5))

    if not query_text:
        return jsonify({'status': 'error', 'message': 'Missing search query'}), 400

    nlp = get_nlp_matcher()
    multimodal = get_multimodal_matcher()
    v_index = get_vector_index()

    q_text_emb = nlp.extract_features(query_text, query_text)
    candidates, text_sims, _, meta = v_index.search_candidates(
        query_item={'title': query_text},
        query_text_emb=q_text_emb,
        query_img_emb=None,
        target_type=target_type,
        top_k=top_k
    )

    ranked = []
    for idx, cand in enumerate(candidates):
        score = float(text_sims[idx]) if idx < len(text_sims) else 0.0
        ranked.append({
            'item_id': cand['id'],
            'title': cand['title'],
            'description': cand['description'],
            'category': cand['category'],
            'location': cand['location'],
            'score': round(score, 4),
            'score_percentage': int(round(score * 100))
        })

    ranked.sort(key=lambda x: x['score'], reverse=True)
    return jsonify({
        'status': 'success',
        'query': query_text,
        'latency_ms': round((time.time() - t0) * 1000, 2),
        'results': ranked[:top_k]
    })

@app.route('/api/v1/detect_category', methods=['POST'])
def api_detect_category():
    """
    Real-time object detection using the N6 Solution tech stack:
    Python, OpenCV, Roboflow, YOLOv8 & YOLO11.
    """
    if 'image' not in request.files:
        return jsonify({'status': 'error', 'message': 'No image file uploaded'}), 400

    file = request.files['image']
    if not file or file.filename == '':
        return jsonify({'status': 'error', 'message': 'Empty file'}), 400

    model_type = request.form.get('model_type', 'yolo11')

    from PIL import Image
    import uuid
    from engine.yolo_detector import get_yolo_detector
    from engine.object_detector import get_object_detector

    # Save to temp file for YOLO processing
    temp_name = f"detect_{uuid.uuid4().hex[:8]}.jpg"
    temp_path = os.path.join(app.config['UPLOAD_FOLDER'], temp_name)
    file.save(temp_path)

    try:
        # 1. Real-Time Object Detection (YOLO11 or YOLOv8)
        yolo = get_yolo_detector()
        yolo_res = yolo.detect(temp_path, model_type=model_type, save_annotated=True, original_filename=file.filename)

        if yolo_res.get('success'):
            annotated_url = url_for('static', filename=yolo_res['annotated_image']) if yolo_res.get('annotated_image') else None
            return jsonify({
                'success': True,
                'model_used': f"{yolo_res['model_used']} Real-Time Detector (Unit III)",
                'detected_object': yolo_res['detected_object'],
                'raw_class': yolo_res['raw_yolo_class'],
                'confidence': yolo_res['confidence'],
                'category': yolo_res['category'],
                'latency_ms': yolo_res.get('latency_ms'),
                'annotated_image_url': annotated_url,
                'tech_stack': 'Python • OpenCV • Roboflow • ' + yolo_res['model_used']
            })

        # 2. Fallback to Deep Vision Classifier (ResNet-50 / Roboflow)
        img = Image.open(temp_path).convert('RGB')
        detector = get_object_detector()
        fallback_res = detector.detect_category(img)
        fallback_res['model_used'] = 'ResNet-50 Feature Classifier (Unit III)'
        return jsonify(fallback_res)

    except Exception as e:
        return jsonify({'status': 'error', 'error': str(e)}), 500
    finally:
        # Clean up raw temp file
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except Exception:
                pass

@app.route('/api/v1/compare_models', methods=['POST'])
def api_compare_models():
    """
    Compares YOLOv8 and YOLO11 side-by-side on an uploaded image,
    matching the N6 Solution case study methodology.
    """
    if 'image' not in request.files:
        return jsonify({'status': 'error', 'message': 'No image file uploaded'}), 400

    file = request.files['image']
    if not file or file.filename == '':
        return jsonify({'status': 'error', 'message': 'Empty file'}), 400

    import uuid
    from engine.yolo_detector import get_yolo_detector

    temp_name = f"comp_{uuid.uuid4().hex[:8]}.jpg"
    temp_path = os.path.join(app.config['UPLOAD_FOLDER'], temp_name)
    file.save(temp_path)

    try:
        yolo = get_yolo_detector()
        comp_res = yolo.compare_models(temp_path, original_filename=file.filename)

        for m_key in ['yolov8', 'yolo11']:
            if comp_res[m_key].get('annotated_image'):
                comp_res[m_key]['annotated_url'] = url_for('static', filename=comp_res[m_key]['annotated_image'])

        return jsonify({
            'success': True,
            'comparison': comp_res,
            'tech_stack': 'Python • OpenCV • Roboflow • YOLOv8 • YOLO11'
        })
    except Exception as e:
        return jsonify({'status': 'error', 'error': str(e)}), 500
    finally:
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except Exception:
                pass

if __name__ == '__main__':
    init_db()
    print("=" * 60)
    print("CampusConnect AI High-Performance Server Starting...")
    print("Local URL: http://127.0.0.1:5001")
    print("=" * 60)
    app.run(host='127.0.0.1', port=5001, debug=True)
