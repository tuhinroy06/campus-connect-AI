import os
import sys
import sqlite3
import numpy as np

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, BASE_DIR)

from config import DATABASE_PATH, SUPABASE_URL, SUPABASE_KEY, USE_SUPABASE
from database.db_manager import deserialize_embedding

def migrate():
    print("=" * 70)
    print("CampusConnect AI: SQLite to Supabase Cloud Migration Tool")
    print("=" * 70)

    if not USE_SUPABASE:
        print("\n[Notice] Supabase is not configured yet!")
        print("Please set your credentials in environment or config.py:")
        print("  export SUPABASE_URL='https://your-project.supabase.co'")
        print("  export SUPABASE_KEY='your-anon-or-service-role-key'\n")
        return False

    try:
        from supabase import create_client
        client = create_client(SUPABASE_URL, SUPABASE_KEY)
        print(f"[Supabase] Connected to: {SUPABASE_URL}")
    except Exception as e:
        print(f"[Error] Failed to connect to Supabase: {e}")
        return False

    if not os.path.exists(DATABASE_PATH):
        print(f"[Error] Local SQLite database not found at {DATABASE_PATH}")
        return False

    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    # 1. Migrate Users
    print("\n[1/4] Migrating Users...")
    cursor.execute("SELECT * FROM users")
    users = cursor.fetchall()
    user_id_map = {}

    for u in users:
        payload = {
            'name': u['name'],
            'email': u['email'],
            'student_id': u['student_id'],
            'phone': u['phone'],
            'role': u['role']
        }
        try:
            res = client.table('users').upsert(payload, on_conflict='email').execute()
            if res.data:
                user_id_map[u['id']] = res.data[0]['id']
        except Exception as e:
            print(f"  User {u['email']} error: {e}")
    print(f"  ✓ Migrated {len(user_id_map)} users.")

    # 2. Migrate Items
    print("\n[2/4] Migrating Items...")
    cursor.execute("SELECT * FROM items")
    items = cursor.fetchall()
    item_id_map = {}

    for item in items:
        mapped_user_id = user_id_map.get(item['user_id'])
        payload = {
            'user_id': mapped_user_id,
            'type': item['type'],
            'title': item['title'],
            'description': item['description'],
            'category': item['category'],
            'location': item['location'],
            'date_event': item['date_event'],
            'image_path': item['image_path'],
            'contact_info': item['contact_info'],
            'status': item['status']
        }
        try:
            res = client.table('items').insert(payload).execute()
            if res.data:
                item_id_map[item['id']] = res.data[0]['id']
        except Exception as e:
            print(f"  Item #{item['id']} error: {e}")
    print(f"  ✓ Migrated {len(item_id_map)} items.")

    # 3. Migrate Dense Neural Vector Embeddings (pgvector)
    print("\n[3/4] Migrating Deep Vector Embeddings (pgvector)...")
    cursor.execute("SELECT * FROM item_embeddings")
    embeddings = cursor.fetchall()
    migrated_embs = 0

    for emb in embeddings:
        local_item_id = emb['item_id']
        cloud_item_id = item_id_map.get(local_item_id)
        if not cloud_item_id:
            continue

        text_vec = deserialize_embedding(emb['text_embedding'])
        img_vec = deserialize_embedding(emb['image_embedding'])

        payload = {
            'item_id': cloud_item_id,
            'text_embedding': text_vec.tolist() if text_vec is not None else None,
            'image_embedding': img_vec.tolist() if img_vec is not None else None
        }

        try:
            client.table('item_embeddings').upsert(payload).execute()
            migrated_embs += 1
        except Exception as e:
            print(f"  Embedding for item #{cloud_item_id} error: {e}")

    print(f"  ✓ Migrated {migrated_embs} dense vector tensors to pgvector.")

    # 4. Migrate Matches
    print("\n[4/4] Migrating Matches...")
    cursor.execute("SELECT * FROM matches")
    matches = cursor.fetchall()
    migrated_matches = 0

    for m in matches:
        cloud_lost = item_id_map.get(m['lost_item_id'])
        cloud_found = item_id_map.get(m['found_item_id'])
        if not cloud_lost or not cloud_found:
            continue

        payload = {
            'lost_item_id': cloud_lost,
            'found_item_id': cloud_found,
            'total_score': float(m['total_score']),
            'vision_score': float(m['vision_score']),
            'text_score': float(m['text_score']),
            'location_score': float(m['location_score']),
            'status': m['status']
        }

        try:
            client.table('matches').upsert(payload, on_conflict='lost_item_id,found_item_id').execute()
            migrated_matches += 1
        except Exception as e:
            print(f"  Match error: {e}")

    print(f"  ✓ Migrated {migrated_matches} matches.")
    conn.close()

    print("\n" + "=" * 70)
    print("SUCCESS! Local SQLite database completely migrated to Supabase Cloud.")
    print("=" * 70)
    return True

if __name__ == '__main__':
    migrate()
