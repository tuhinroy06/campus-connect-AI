import os
import numpy as np
from config import SUPABASE_URL, SUPABASE_KEY, USE_SUPABASE

_supabase_client = None

def get_supabase_client():
    global _supabase_client
    if _supabase_client is not None:
        return _supabase_client

    if not USE_SUPABASE:
        return None

    try:
        from supabase import create_client
        _supabase_client = create_client(SUPABASE_URL, SUPABASE_KEY)
        print("[Supabase] Successfully connected to Supabase Cloud Database.")
        return _supabase_client
    except Exception as e:
        print(f"[Supabase Warning] Failed to initialize Supabase client: {e}")
        return None

def is_supabase_enabled():
    return bool(USE_SUPABASE and get_supabase_client() is not None)

# -------------------------------------------------------------------------
# Supabase Operations (Users, Items, Embeddings, Matches)
# -------------------------------------------------------------------------

def add_user_supabase(name, email, student_id="", phone="", role="student"):
    client = get_supabase_client()
    if not client:
        return None
    try:
        data = {
            'name': name,
            'email': email,
            'student_id': student_id,
            'phone': phone,
            'role': role
        }
        res = client.table('users').upsert(data, on_conflict='email').execute()
        if res.data and len(res.data) > 0:
            return res.data[0]['id']
    except Exception as e:
        print(f"[Supabase Error] add_user: {e}")
    return None

def add_item_supabase(user_id, item_type, title, description, category, location, date_event, image_path=None, contact_info=""):
    client = get_supabase_client()
    if not client:
        return None
    try:
        item_data = {
            'user_id': user_id,
            'type': item_type,
            'title': title,
            'description': description,
            'category': category,
            'location': location,
            'date_event': date_event,
            'image_path': image_path,
            'contact_info': contact_info,
            'status': 'open'
        }
        res = client.table('items').insert(item_data).execute()
        if res.data and len(res.data) > 0:
            return res.data[0]['id']
    except Exception as e:
        print(f"[Supabase Error] add_item: {e}")
    return None

def save_embeddings_supabase(item_id, text_embedding=None, image_embedding=None):
    client = get_supabase_client()
    if not client:
        return False
    try:
        payload = {'item_id': item_id}
        if text_embedding is not None:
            if isinstance(text_embedding, np.ndarray):
                text_embedding = text_embedding.tolist()
            payload['text_embedding'] = text_embedding

        if image_embedding is not None:
            if isinstance(image_embedding, np.ndarray):
                image_embedding = image_embedding.tolist()
            payload['image_embedding'] = image_embedding

        res = client.table('item_embeddings').upsert(payload).execute()
        return bool(res.data)
    except Exception as e:
        print(f"[Supabase Error] save_embeddings: {e}")
        return False

def record_match_supabase(lost_item_id, found_item_id, total_score, vision_score=0.0, text_score=0.0, location_score=0.0):
    client = get_supabase_client()
    if not client:
        return False
    try:
        match_data = {
            'lost_item_id': lost_item_id,
            'found_item_id': found_item_id,
            'total_score': float(total_score),
            'vision_score': float(vision_score),
            'text_score': float(text_score),
            'location_score': float(location_score),
            'status': 'pending'
        }
        client.table('matches').upsert(match_data, on_conflict='lost_item_id,found_item_id').execute()
        return True
    except Exception as e:
        print(f"[Supabase Error] record_match: {e}")
        return False

def get_items_supabase(item_type=None, limit=100):
    client = get_supabase_client()
    if not client:
        return []
    try:
        q = client.table('items').select('*')
        if item_type:
            q = q.eq('type', item_type)
        res = q.order('created_at', desc=True).limit(limit).execute()
        return res.data or []
    except Exception as e:
        print(f"[Supabase Error] get_items: {e}")
        return []

def get_all_matches_supabase(min_score=0.30, limit=50):
    client = get_supabase_client()
    if not client:
        return []
    try:
        res = client.table('matches').select(
            'id, total_score, vision_score, text_score, location_score, status, '
            'lost_item_id, found_item_id, '
            'lost_items:items!lost_item_id(title, description, location, image_path, users(name)), '
            'found_items:items!found_item_id(title, description, location, image_path, users(name))'
        ).gte('total_score', min_score).order('total_score', desc=True).limit(limit).execute()
        return res.data or []
    except Exception as e:
        print(f"[Supabase Error] get_all_matches: {e}")
        return []

def search_semantic_rpc_supabase(query_vector, filter_type='found', threshold=0.30, count=10):
    """
    Executes in-database pgvector similarity search via Supabase RPC function.
    """
    client = get_supabase_client()
    if not client:
        return []
    try:
        if isinstance(query_vector, np.ndarray):
            query_vector = query_vector.tolist()
        params = {
            'query_vector': query_vector,
            'match_threshold': float(threshold),
            'match_count': int(count),
            'filter_type': filter_type
        }
        res = client.rpc('search_items_by_text_embedding', params).execute()
        return res.data or []
    except Exception as e:
        print(f"[Supabase Error] search_semantic_rpc: {e}")
        return []
