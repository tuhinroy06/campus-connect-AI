import sqlite3
import os
import json
import numpy as np
from config import DATABASE_PATH

def get_db_connection():
    os.makedirs(os.path.dirname(DATABASE_PATH), exist_ok=True)
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    schema_path = os.path.join(os.path.dirname(__file__), 'schema.sql')
    with open(schema_path, 'r') as f:
        schema_sql = f.read()
    conn = get_db_connection()
    conn.executescript(schema_sql)
    conn.commit()
    conn.close()

# Serialization helpers for numpy embeddings
def serialize_embedding(vec):
    if vec is None:
        return None
    if isinstance(vec, list):
        vec = np.array(vec, dtype=np.float32)
    return vec.astype(np.float32).tobytes()

def deserialize_embedding(blob):
    if blob is None:
        return None
    return np.frombuffer(blob, dtype=np.float32)

# User operations
def add_user(name, email, student_id="", phone="", role="student"):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO users (name, email, student_id, phone, role)
        VALUES (?, ?, ?, ?, ?)
    """, (name, email, student_id, phone, role))
    user_id = cursor.lastrowid
    conn.commit()
    conn.close()

    # Sync user to Supabase Cloud if configured
    try:
        from config import USE_SUPABASE
        if USE_SUPABASE:
            from database.supabase_manager import add_user_supabase
            add_user_supabase(name, email, student_id, phone, role)
    except Exception:
        pass

    return user_id

def get_user_by_email(email):
    conn = get_db_connection()
    user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    conn.close()
    return dict(user) if user else None

def get_or_create_user(name, email, student_id="", phone=""):
    user = get_user_by_email(email)
    if user:
        return user['id']
    return add_user(name, email, student_id, phone)

# Item operations
def add_item(user_id, item_type, title, description, category, location, date_event, image_path=None, contact_info=""):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO items (user_id, type, title, description, category, location, date_event, image_path, contact_info)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (user_id, item_type, title, description, category, location, date_event, image_path, contact_info))
    item_id = cursor.lastrowid
    conn.commit()
    conn.close()

    # Sync embeddings to Supabase Cloud (pgvector) if configured
    try:
        from config import USE_SUPABASE
        if USE_SUPABASE:
            from database.supabase_manager import save_embeddings_supabase
            save_embeddings_supabase(item_id, text_embedding, image_embedding)
    except Exception:
        pass

    # Sync to Supabase Cloud if configured
    try:
        from config import USE_SUPABASE
        if USE_SUPABASE:
            from database.supabase_manager import add_item_supabase
            add_item_supabase(user_id, item_type, title, description, category, location, date_event, image_path, contact_info)
    except Exception:
        pass

    return item_id

def get_item(item_id):
    conn = get_db_connection()
    item = conn.execute("""
        SELECT i.*, u.name as reporter_name, u.email as reporter_email, u.phone as reporter_phone
        FROM items i
        LEFT JOIN users u ON i.user_id = u.id
        WHERE i.id = ?
    """, (item_id,)).fetchone()
    conn.close()
    return dict(item) if item else None

def get_items(item_type=None, status=None, limit=100):
    conn = get_db_connection()
    query = "SELECT i.*, u.name as reporter_name FROM items i LEFT JOIN users u ON i.user_id = u.id WHERE 1=1"
    params = []
    if item_type:
        query += " AND i.type = ?"
        params.append(item_type)
    if status:
        query += " AND i.status = ?"
        params.append(status)
    query += " ORDER BY i.created_at DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(query, tuple(params)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def update_item_status(item_id, status):
    conn = get_db_connection()
    conn.execute("UPDATE items SET status = ? WHERE id = ?", (status, item_id))
    if status == 'resolved':
        conn.execute("UPDATE matches SET status = 'confirmed' WHERE lost_item_id = ? OR found_item_id = ?", (item_id, item_id))
    conn.commit()
    conn.close()

# Embedding storage
def save_embeddings(item_id, text_embedding=None, image_embedding=None):
    conn = get_db_connection()
    text_blob = serialize_embedding(text_embedding)
    image_blob = serialize_embedding(image_embedding)
    conn.execute("""
        INSERT OR REPLACE INTO item_embeddings (item_id, text_embedding, image_embedding)
        VALUES (?, ?, ?)
    """, (item_id, text_blob, image_blob))
    conn.commit()
    conn.close()

    # Sync embeddings to Supabase Cloud (pgvector) if configured
    try:
        from config import USE_SUPABASE
        if USE_SUPABASE:
            from database.supabase_manager import save_embeddings_supabase
            save_embeddings_supabase(item_id, text_embedding, image_embedding)
    except Exception:
        pass

def get_item_embeddings(item_id):
    conn = get_db_connection()
    row = conn.execute("SELECT * FROM item_embeddings WHERE item_id = ?", (item_id,)).fetchone()
    conn.close()
    if not row:
        return None, None
    return deserialize_embedding(row['text_embedding']), deserialize_embedding(row['image_embedding'])

def get_candidates_for_matching(candidate_type, exclude_id=None):
    """
    Returns all candidate items of given type ('lost' or 'found') along with their deserialized embeddings.
    """
    conn = get_db_connection()
    query = """
        SELECT i.*, e.text_embedding, e.image_embedding, u.name as reporter_name, u.email as reporter_email
        FROM items i
        LEFT JOIN item_embeddings e ON i.id = e.item_id
        LEFT JOIN users u ON i.user_id = u.id
        WHERE i.type = ? AND i.status != 'resolved'
    """
    params = [candidate_type]
    if exclude_id:
        query += " AND i.id != ?"
        params.append(exclude_id)
    query += " ORDER BY i.created_at DESC"
    rows = conn.execute(query, tuple(params)).fetchall()
    conn.close()

    candidates = []
    for r in rows:
        d = dict(r)
        d['text_embedding'] = deserialize_embedding(d.pop('text_embedding'))
        d['image_embedding'] = deserialize_embedding(d.pop('image_embedding'))
        candidates.append(d)
    return candidates

# Match record operations
def record_match(lost_item_id, found_item_id, total_score, vision_score=0.0, text_score=0.0, location_score=0.0):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO matches (lost_item_id, found_item_id, total_score, vision_score, text_score, location_score)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(lost_item_id, found_item_id) DO UPDATE SET
            total_score=excluded.total_score,
            vision_score=excluded.vision_score,
            text_score=excluded.text_score,
            location_score=excluded.location_score
    """, (lost_item_id, found_item_id, total_score, vision_score, text_score, location_score))
    match_id = cursor.lastrowid
    conn.commit()
    conn.close()

    # Sync match to Supabase Cloud if configured
    try:
        from config import USE_SUPABASE
        if USE_SUPABASE:
            from database.supabase_manager import record_match_supabase
            record_match_supabase(lost_item_id, found_item_id, total_score, vision_score, text_score, location_score)
    except Exception:
        pass

    return match_id

def get_matches_for_item(item_id, item_type):
    """
    Fetch matches where the item is either lost or found, along with corresponding other item info.
    """
    conn = get_db_connection()
    if item_type == 'lost':
        query = """
            SELECT m.*, 
                   f.id as matched_id, f.title as matched_title, f.description as matched_description,
                   f.location as matched_location, f.date_event as matched_date, f.image_path as matched_image,
                   f.category as matched_category, f.contact_info as matched_contact,
                   u.name as matched_reporter
            FROM matches m
            JOIN items f ON m.found_item_id = f.id
            LEFT JOIN users u ON f.user_id = u.id
            WHERE m.lost_item_id = ? AND m.status != 'confirmed' AND f.status != 'resolved'
            ORDER BY m.total_score DESC
        """
    else:
        query = """
            SELECT m.*, 
                   l.id as matched_id, l.title as matched_title, l.description as matched_description,
                   l.location as matched_location, l.date_event as matched_date, l.image_path as matched_image,
                   l.category as matched_category, l.contact_info as matched_contact,
                   u.name as matched_reporter
            FROM matches m
            JOIN items l ON m.lost_item_id = l.id
            LEFT JOIN users u ON l.user_id = u.id
            WHERE m.found_item_id = ? AND m.status != 'confirmed' AND l.status != 'resolved'
            ORDER BY m.total_score DESC
        """
    rows = conn.execute(query, (item_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_all_matches(min_score=0.20, limit=50):
    conn = get_db_connection()
    query = """
        SELECT m.*,
               l.title as lost_title, l.description as lost_description, l.image_path as lost_image,
               l.location as lost_location, l.date_event as lost_date,
               f.title as found_title, f.description as found_description, f.image_path as found_image,
               f.location as found_location, f.date_event as found_date,
               lu.name as lost_reporter, fu.name as found_reporter
        FROM matches m
        JOIN items l ON m.lost_item_id = l.id
        JOIN items f ON m.found_item_id = f.id
        LEFT JOIN users lu ON l.user_id = lu.id
        LEFT JOIN users fu ON f.user_id = fu.id
        WHERE m.total_score >= ?
          AND m.status != 'confirmed'
          AND l.status != 'resolved'
          AND f.status != 'resolved'
        ORDER BY m.total_score DESC
        LIMIT ?
    """
    rows = conn.execute(query, (min_score, limit)).fetchall()
    conn.close()
    return [dict(r) for r in rows]

def get_dashboard_stats():
    conn = get_db_connection()
    total_lost = conn.execute("SELECT COUNT(*) FROM items WHERE type='lost' AND status != 'resolved'").fetchone()[0]
    total_found = conn.execute("SELECT COUNT(*) FROM items WHERE type='found' AND status != 'resolved'").fetchone()[0]
    total_matches = conn.execute("""
        SELECT COUNT(*) FROM matches m
        JOIN items l ON m.lost_item_id = l.id
        JOIN items f ON m.found_item_id = f.id
        WHERE m.total_score >= 0.50 AND m.status != 'confirmed' AND l.status != 'resolved' AND f.status != 'resolved'
    """).fetchone()[0]
    total_resolved = conn.execute("SELECT COUNT(*) FROM items WHERE status='resolved'").fetchone()[0]
    recent_items = conn.execute("""
        SELECT i.*, u.name as reporter_name 
        FROM items i LEFT JOIN users u ON i.user_id = u.id 
        WHERE i.status != 'resolved'
        ORDER BY i.created_at DESC LIMIT 6
    """).fetchall()
    conn.close()
    return {
        'total_lost': total_lost,
        'total_found': total_found,
        'total_matches': total_matches,
        'total_resolved': total_resolved,
        'recent_items': [dict(r) for r in recent_items]
    }
